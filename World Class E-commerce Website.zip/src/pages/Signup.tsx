import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Eye, EyeOff, Mail, Lock, User, Phone, ArrowRight, MapPin } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Signup() {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = searchParams.get("redirect") || "/";

  const [form, setForm] = useState({
    name: "", email: "", phone: "", password: "", confirm: "",
    address: "", city: "", pincode: "",
  });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (step === 1) { setStep(2); return; }
    if (form.password !== form.confirm) { setError("Passwords do not match."); return; }
    setError("");
    setLoading(true);
    const result = await signup(form);
    setLoading(false);
    if (result.success) navigate(redirect);
    else setError(result.error || "Signup failed.");
  }

  return (
    <div className="min-h-screen flex" style={{ background: "#FFF8F0" }}>
      {/* Left */}
      <div className="hidden lg:flex flex-col justify-between p-12 w-[45%]"
        style={{ background: "linear-gradient(160deg, #8B1A1A 0%, #C8421A 60%, #9E3214 100%)" }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
            <span style={{ fontFamily: "'Playfair Display', serif", color: "#C8421A", fontWeight: 800 }}>BT</span>
          </div>
          <div>
            <div style={{ fontFamily: "'Playfair Display', serif" }} className="text-white font-bold text-lg">Bihari Thekua</div>
            <div className="text-orange-200 text-[10px] uppercase tracking-widest">Authentic Taste of Bihar</div>
          </div>
        </div>
        <div>
          <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-4xl font-bold text-white leading-tight mb-4">
            Join the Bihari Thekua Family
          </h2>
          <p className="text-orange-200 text-sm leading-relaxed">
            Create your free account and get access to exclusive offers, easy checkout, and order tracking.
          </p>
          <div className="mt-8 p-5 rounded-2xl" style={{ background: "#00000020" }}>
            <p className="text-yellow-400 text-sm font-semibold mb-2">🎁 New Member Offer</p>
            <p className="text-white text-sm">Use code <strong className="text-yellow-300">WELCOME10</strong> on your first order for 10% off!</p>
          </div>
        </div>
        <div className="text-orange-300 text-xs">© 2024 Bihari Thekua. All rights reserved.</div>
      </div>

      {/* Right */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              {[1, 2].map(s => (
                <div key={s} className="flex items-center gap-2">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${step >= s ? "text-white" : "bg-gray-200 text-gray-500"}`}
                    style={step >= s ? { background: "#C8421A" } : {}}>
                    {s}
                  </div>
                  <span className="text-xs text-gray-500">{s === 1 ? "Personal Info" : "Address"}</span>
                  {s < 2 && <div className={`h-px w-8 ${step > s ? "" : "bg-gray-200"}`} style={step > s ? { background: "#C8421A" } : {}} />}
                </div>
              ))}
            </div>
            <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800 mb-2">
              {step === 1 ? "Create Account" : "Delivery Address"}
            </h1>
            <p className="text-sm text-gray-500">
              Already have an account? <Link to={`/login?redirect=${redirect}`} style={{ color: "#C8421A" }} className="font-medium hover:underline">Sign in</Link>
            </p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {step === 1 ? (
              <>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">Full Name *</label>
                  <div className="relative">
                    <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="text" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                      placeholder="Rahul Kumar" className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">Email Address *</label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
                      placeholder="you@example.com" className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">Phone Number *</label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="tel" required value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}
                      placeholder="9876543210" className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">Password *</label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type={showPass ? "text" : "password"} required value={form.password} onChange={e => setForm({ ...form, password: e.target.value })}
                      placeholder="Min. 6 characters" className="w-full pl-10 pr-10 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                    <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400">
                      {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">Confirm Password *</label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="password" required value={form.confirm} onChange={e => setForm({ ...form, confirm: e.target.value })}
                      placeholder="Repeat password" className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                  </div>
                </div>
              </>
            ) : (
              <>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">Street Address</label>
                  <div className="relative">
                    <MapPin size={16} className="absolute left-3.5 top-3.5 text-gray-400" />
                    <textarea value={form.address} onChange={e => setForm({ ...form, address: e.target.value })}
                      placeholder="House No, Street, Area" rows={2}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white resize-none" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1.5">City</label>
                    <input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })}
                      placeholder="Patna" className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1.5">PIN Code</label>
                    <input value={form.pincode} onChange={e => setForm({ ...form, pincode: e.target.value })}
                      placeholder="800001" className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                  </div>
                </div>
                <p className="text-xs text-gray-400">Address can be updated later in your profile. You can also enter it at checkout.</p>
              </>
            )}

            <div className="flex gap-3 pt-1">
              {step === 2 && (
                <button type="button" onClick={() => setStep(1)}
                  className="flex-1 py-3.5 rounded-xl border-2 border-orange-200 text-orange-700 font-semibold text-sm hover:bg-orange-50 transition-colors">
                  Back
                </button>
              )}
              <button type="submit" disabled={loading}
                style={{ background: "#C8421A" }}
                className="flex-1 py-3.5 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-70">
                {loading ? "Creating account..." : step === 1 ? <><span>Continue</span> <ArrowRight size={16} /></> : <><span>Create Account</span> <ArrowRight size={16} /></>}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
