import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { CheckCircle, Package, MapPin, Download, ArrowRight } from "lucide-react";
import { getOrderById, Order } from "../services/db";

export default function OrderSuccess() {
  const { orderId } = useParams();
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (orderId) setOrder(getOrderById(orderId));
  }, [orderId]);

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#FFF8F0" }}>
        <div className="text-center">
          <div className="text-5xl mb-4">🔍</div>
          <p className="text-gray-600">Order not found</p>
          <Link to="/" style={{ color: "#C8421A" }} className="text-sm font-medium mt-2 block">Back to Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 px-4" style={{ background: "#FFF8F0" }}>
      <div className="max-w-2xl mx-auto">
        {/* Success header */}
        <div className="text-center mb-8 fade-in">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "#f0fdf4" }}>
            <CheckCircle size={40} className="text-green-500" />
          </div>
          <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800 mb-2">Order Placed Successfully!</h1>
          <p className="text-gray-500 text-sm">Thank you for your order. We'll start preparing your sweets right away.</p>
        </div>

        {/* Order ID */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100 mb-5 fade-in">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <p className="text-xs text-gray-400 font-medium">Order ID</p>
              <p className="font-bold text-gray-800 text-lg">{order.id}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-400">Payment ID</p>
              <p className="text-xs font-medium text-gray-600">{order.paymentId}</p>
            </div>
            <span className="px-3 py-1.5 rounded-full text-xs font-bold text-white" style={{ background: "#16a34a" }}>
              ✓ Paid
            </span>
          </div>
        </div>

        {/* Delivery address */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100 mb-5">
          <h3 className="font-semibold text-sm text-gray-800 flex items-center gap-2 mb-3">
            <MapPin size={16} style={{ color: "#C8421A" }} /> Delivery Address
          </h3>
          <p className="text-sm font-medium text-gray-700">{order.userName} · {order.userPhone}</p>
          <p className="text-xs text-gray-500 mt-1">{order.address}, {order.city} — {order.pincode}</p>
        </div>

        {/* Items */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100 mb-5">
          <h3 className="font-semibold text-sm text-gray-800 flex items-center gap-2 mb-4">
            <Package size={16} style={{ color: "#C8421A" }} /> Items Ordered
          </h3>
          <div className="space-y-3">
            {order.items.map((item, i) => (
              <div key={i} className="flex gap-3 items-center">
                <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-800">{item.name}</p>
                  <p className="text-xs text-gray-400">{item.weight} × {item.quantity}</p>
                </div>
                <span className="text-sm font-bold" style={{ color: "#C8421A" }}>₹{item.price * item.quantity}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-orange-100 mt-4 pt-4 space-y-1.5 text-sm">
            <div className="flex justify-between text-gray-500"><span>Subtotal</span><span>₹{order.subtotal}</span></div>
            {order.couponCode && <div className="flex justify-between text-green-600"><span>Coupon ({order.couponCode})</span><span>-₹{order.discount || 0}</span></div>}
            <div className="flex justify-between text-gray-500"><span>Delivery</span><span>{order.deliveryCharge === 0 ? "FREE" : `₹${order.deliveryCharge}`}</span></div>
            <div className="flex justify-between font-bold text-base pt-1 border-t border-orange-100" style={{ color: "#C8421A" }}>
              <span>Total Paid</span><span>₹{order.total}</span>
            </div>
          </div>
        </div>

        {/* Estimated delivery */}
        <div className="bg-orange-50 rounded-2xl p-5 border border-orange-200 mb-6">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🚚</span>
            <div>
              <p className="font-semibold text-gray-800 text-sm">Estimated Delivery</p>
              <p className="text-orange-700 text-sm font-medium">
                {new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}
              </p>
              <p className="text-xs text-gray-500 mt-1">A tracking link will be sent to {order.userEmail}</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <Link to="/orders"
            style={{ border: "2px solid #C8421A", color: "#C8421A" }}
            className="flex-1 py-3 rounded-xl text-sm font-semibold text-center hover:bg-orange-50 transition-colors flex items-center justify-center gap-2">
            <Package size={16} /> Track Order
          </Link>
          <Link to="/products"
            style={{ background: "#C8421A" }}
            className="flex-1 py-3 rounded-xl text-white text-sm font-semibold text-center hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
            Continue Shopping <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}
