import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Eye, EyeOff, Mail, Lock, ArrowRight } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = searchParams.get("redirect") || "/";

  const [form, setForm] = useState({ email: "", password: "" });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const result = await login(form.email.trim(), form.password);
    setLoading(false);
    if (result.success) navigate(redirect);
    else setError(result.error || "Login failed.");
  }

  return (
    <div className="min-h-screen flex" style={{ background: "#FFF8F0" }}>
      {/* Left panel */}
      <div className="hidden lg:flex flex-col justify-between p-12 w-[45%]"
        style={{ background: "linear-gradient(160deg, #8B1A1A 0%, #C8421A 60%, #D4A017 100%)" }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
            <span style={{ fontFamily: "'Playfair Display', serif", color: "#C8421A", fontWeight: 800 }}>BT</span>
          </div>
          <div>
            <div style={{ fontFamily: "'Playfair Display', serif" }} className="text-white font-bold text-lg leading-tight">Bihari Thekua</div>
            <div className="text-orange-200 text-[10px] uppercase tracking-widest">Authentic Taste of Bihar</div>
          </div>
        </div>
        <div>
          <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-4xl font-bold text-white leading-tight mb-4">
            Welcome Back to<br />Bihar's Finest Sweets
          </h2>
          <p className="text-orange-200 text-sm leading-relaxed">
            Sign in to access your orders, track deliveries, and enjoy exclusive member offers on our handcrafted Thekua and traditional Bihar sweets.
          </p>
          <div className="mt-8 space-y-4">
            {["Free delivery on all orders above ₹499", "Exclusive member discounts every week", "Order tracking and history at your fingertips"].map(text => (
              <div key={text} className="flex items-center gap-3 text-sm text-orange-100">
                <span className="text-yellow-400">✓</span> {text}
              </div>
            ))}
          </div>
        </div>
        <div className="text-orange-300 text-xs">© 2024 Bihari Thekua. All rights reserved.</div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800 mb-2">Sign In</h1>
            <p className="text-sm text-gray-500">Don't have an account? <Link to={`/signup?redirect=${redirect}`} style={{ color: "#C8421A" }} className="font-medium hover:underline">Create one free</Link></p>
          </div>

          {/* Demo credentials hint */}
          <div className="mb-5 p-3 rounded-xl bg-orange-50 border border-orange-200 text-xs text-gray-600">
            <strong>Admin demo:</strong> admin@biharithekua.com / Admin@123
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type={showPass ? "text" : "password"}
                  required
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  placeholder="Your password"
                  className="w-full pl-10 pr-10 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white"
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              style={{ background: "#C8421A" }}
              className="w-full py-3.5 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-70">
              {loading ? "Signing in..." : <><span>Sign In</span> <ArrowRight size={16} /></>}
            </button>
          </form>

          <div className="mt-4 text-center">
            <Link to="/signup" className="text-xs text-gray-400 hover:underline">Forgot password?</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
