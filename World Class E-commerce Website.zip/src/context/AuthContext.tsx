import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, getSession, setSession, clearSession, findUserByEmail, createUser, hashPassword, verifyPassword, seedAdmin } from "../services/db";

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (data: SignupData) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
  isAdmin: boolean;
}

interface SignupData {
  name: string;
  email: string;
  phone: string;
  password: string;
  address?: string;
  city?: string;
  pincode?: string;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    seedAdmin();
    const session = getSession();
    if (session) setUser(session);
  }, []);

  async function login(email: string, password: string) {
    const found = findUserByEmail(email);
    if (!found) return { success: false, error: "No account found with this email." };

    const valid = verifyPassword(password, found.password);
    if (!valid) return { success: false, error: "Incorrect password. Please try again." };

    setSession(found);
    setUser(found);
    return { success: true };
  }

  async function signup(data: SignupData) {
    const existing = findUserByEmail(data.email);
    if (existing) return { success: false, error: "An account with this email already exists." };

    if (data.password.length < 6) return { success: false, error: "Password must be at least 6 characters." };

    const newUser = createUser({
      name: data.name,
      email: data.email,
      phone: data.phone,
      password: hashPassword(data.password),
      address: data.address || "",
      city: data.city || "",
      pincode: data.pincode || "",
    });

    setSession(newUser);
    setUser(newUser);
    return { success: true };
  }

  function logout() {
    clearSession();
    setUser(null);
  }

  function updateProfile(updates: Partial<User>) {
    if (!user) return;
    const updated = { ...user, ...updates };
    setUser(updated);
    import("../services/db").then(({ saveUser }) => saveUser(updated));
  }

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateProfile, isAdmin: user?.role === "admin" }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
