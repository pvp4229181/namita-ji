import { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ShoppingCart, User, Search, Menu, X, ChevronDown, LogOut, Package, Settings, LayoutDashboard, Phone, Mail } from "lucide-react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { totalItems, openCart } = useCart();
  const { user, logout, isAdmin } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function handleLogout() {
    logout();
    setProfileOpen(false);
    navigate("/");
  }

  return (
    <header className="sticky top-0 z-50 shadow-sm">
      {/* Top bar */}
      <div style={{ background: "#8B1A1A" }} className="text-white text-xs py-1.5 px-4 hidden md:flex justify-between items-center">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1"><Phone size={11} /> +91 98765 43210</span>
          <span className="flex items-center gap-1"><Mail size={11} /> hello@biharithekua.com</span>
        </div>
        <div className="flex gap-4 text-xs opacity-90">
          <span>🚚 Free delivery above ₹499</span>
          <span>•</span>
          <span>🏅 FSSAI Certified</span>
          <span>•</span>
          <span>📦 Pan-India Shipping</span>
        </div>
      </div>

      {/* Main navbar */}
      <nav style={{ background: "#C8421A" }} className="px-4 md:px-8 py-3 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow">
            <span style={{ fontFamily: "'Playfair Display', serif", color: "#C8421A", fontWeight: 800, fontSize: "14px" }}>BT</span>
          </div>
          <div className="hidden sm:block">
            <div style={{ fontFamily: "'Playfair Display', serif" }} className="text-white font-bold text-lg leading-tight">Bihari Thekua</div>
            <div className="text-orange-200 text-[10px] uppercase tracking-widest">Authentic Taste of Bihar</div>
          </div>
        </Link>

        {/* Nav links desktop */}
        <nav className="hidden md:flex items-center gap-6 text-white text-sm font-medium">
          <Link to="/" className="hover:text-yellow-300 transition-colors">Home</Link>
          <Link to="/products" className="hover:text-yellow-300 transition-colors">Shop</Link>
          <Link to="/products?category=Gift+Boxes" className="hover:text-yellow-300 transition-colors">Gift Boxes</Link>
          <Link to="/products?category=Thekua" className="hover:text-yellow-300 transition-colors">Thekua</Link>
          <Link to="/about" className="hover:text-yellow-300 transition-colors">About</Link>
        </nav>

        {/* Right icons */}
        <div className="flex items-center gap-2">
          {/* Search */}
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="p-2 text-white hover:bg-white/20 rounded-full transition-colors"
          >
            <Search size={20} />
          </button>

          {/* Profile */}
          <div className="relative" ref={profileRef}>
            <button
              onClick={() => { if (!user) navigate("/login"); else setProfileOpen(!profileOpen); }}
              className="p-2 text-white hover:bg-white/20 rounded-full transition-colors flex items-center gap-1"
            >
              <div className="w-8 h-8 rounded-full bg-yellow-400 flex items-center justify-center text-red-800 font-bold text-sm">
                {user ? user.name[0].toUpperCase() : <User size={16} />}
              </div>
              {user && <ChevronDown size={14} className="hidden md:block text-white/80" />}
            </button>

            {profileOpen && user && (
              <div className="absolute right-0 mt-2 w-60 bg-white rounded-xl shadow-2xl border border-orange-100 overflow-hidden z-50 fade-in">
                {/* Profile header */}
                <div style={{ background: "#FFF8F0" }} className="px-4 py-3 border-b border-orange-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold">
                      {user.name[0].toUpperCase()}
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-gray-800">{user.name}</div>
                      <div className="text-xs text-gray-500">{user.email}</div>
                    </div>
                  </div>
                </div>
                {/* Menu items */}
                <div className="py-1">
                  <Link to="/profile" onClick={() => setProfileOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-orange-50 transition-colors">
                    <User size={16} className="text-orange-500" /> My Account
                  </Link>
                  <Link to="/orders" onClick={() => setProfileOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-orange-50 transition-colors">
                    <Package size={16} className="text-orange-500" /> My Orders
                  </Link>
                  {isAdmin && (
                    <Link to="/admin" onClick={() => setProfileOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-orange-50 transition-colors">
                      <LayoutDashboard size={16} className="text-orange-500" /> Admin Panel
                    </Link>
                  )}
                  <Link to="/profile/settings" onClick={() => setProfileOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-700 hover:bg-orange-50 transition-colors">
                    <Settings size={16} className="text-orange-500" /> Settings
                  </Link>
                  <hr className="my-1 border-orange-100" />
                  <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors">
                    <LogOut size={16} /> Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Cart */}
          <button
            onClick={openCart}
            className="relative p-2 text-white hover:bg-white/20 rounded-full transition-colors"
          >
            <ShoppingCart size={22} />
            {totalItems > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-yellow-400 text-red-900 text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow">
                {totalItems > 99 ? "99+" : totalItems}
              </span>
            )}
          </button>

          {/* Mobile menu */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="p-2 text-white md:hidden hover:bg-white/20 rounded-full transition-colors"
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* Search bar */}
      {searchOpen && (
        <div className="bg-white border-b border-orange-200 px-4 py-3 fade-in">
          <div className="max-w-2xl mx-auto relative">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              autoFocus
              placeholder="Search for Thekua, Laddoo, Gift boxes..."
              className="w-full pl-10 pr-4 py-2.5 border border-orange-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
              onKeyDown={e => {
                if (e.key === "Enter") {
                  navigate(`/products?q=${(e.target as HTMLInputElement).value}`);
                  setSearchOpen(false);
                }
              }}
            />
          </div>
        </div>
      )}

      {/* Mobile nav */}
      {menuOpen && (
        <div style={{ background: "#9E3214" }} className="md:hidden px-4 py-4 space-y-3 fade-in">
          {["Home:/", "Shop:/products", "Gift Boxes:/products?category=Gift+Boxes", "Thekua:/products?category=Thekua", "About:/about"].map(item => {
            const [label, path] = item.split(":");
            return (
              <Link key={label} to={path} onClick={() => setMenuOpen(false)}
                className="block text-white text-sm font-medium py-2 border-b border-white/20">{label}</Link>
            );
          })}
        </div>
      )}
    </header>
  );
}
