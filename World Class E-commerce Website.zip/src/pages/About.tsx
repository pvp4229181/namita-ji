import { Link } from "react-router-dom";
import { Award, Heart, Leaf, Truck } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen" style={{ background: "#FFF8F0" }}>
      {/* Hero */}
      <div style={{ background: "linear-gradient(135deg, #8B1A1A 0%, #C8421A 100%)" }} className="py-20 px-6 text-center text-white">
        <p className="text-yellow-400 text-xs font-medium uppercase tracking-widest mb-3">Our Story</p>
        <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-4xl md:text-5xl font-bold mb-4">The Heart of Bihar, In Every Bite</h1>
        <p className="text-orange-200 text-base max-w-2xl mx-auto">From the sacred ghats of Chhath to your doorstep — we bring you the most authentic handcrafted Bihar sweets, made with love and generations of tradition.</p>
      </div>

      {/* Story */}
      <section className="py-16 px-6 max-w-5xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img src="https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=600&h=500&fit=crop&auto=format" alt="Traditional Bihar kitchen" className="rounded-2xl shadow-xl" />
          </div>
          <div>
            <p className="text-sm font-medium uppercase tracking-widest mb-3" style={{ color: "#C8421A" }}>Est. 2018, Patna, Bihar</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800 mb-5">Started With a Mother's Recipe</h2>
            <p className="text-gray-600 leading-relaxed mb-4 text-sm">
              It started in a small kitchen in Patna, where our founder's mother would spend days before Chhath Puja making the perfect Thekua — crisp outside, fragrant with fennel and cardamom, and enriched with pure desi ghee.
            </p>
            <p className="text-gray-600 leading-relaxed mb-4 text-sm">
              When friends and family couldn't stop asking for more, the decision was made: to bring this heritage to every Bihar household across India.
            </p>
            <p className="text-gray-600 leading-relaxed text-sm">
              Today, we work with a small team of skilled artisans from Bihar, using the exact same recipes — no shortcuts, no preservatives, no compromise on quality.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section style={{ background: "white" }} className="py-16 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <p className="text-sm font-medium uppercase tracking-widest mb-3" style={{ color: "#C8421A" }}>Our Promise</p>
          <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800 mb-10">What Makes Us Different</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Leaf, title: "No Preservatives", desc: "Pure ingredients only — desi ghee, jaggery, whole wheat. Nothing artificial, ever." },
              { icon: Heart, title: "Made with Love", desc: "Every batch is handcrafted by skilled Bihar artisans following family recipes." },
              { icon: Award, title: "FSSAI Certified", desc: "Fully certified and regularly audited for food safety and quality standards." },
              { icon: Truck, title: "Pan-India Shipping", desc: "Delivered fresh across India — from Leh to Kanyakumari, in temperature-controlled packaging." },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="text-center">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ background: "#FFF0E8" }}>
                  <Icon size={24} style={{ color: "#C8421A" }} />
                </div>
                <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="font-bold text-gray-800 mb-2">{title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ background: "#8B1A1A" }} className="py-14 px-6 text-center text-white">
        <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold mb-4">Taste the Heritage Today</h2>
        <p className="text-orange-200 mb-8 text-sm">Free delivery on orders above ₹499. Use code WELCOME10 for 10% off your first order.</p>
        <Link to="/products" style={{ background: "#D4A017", color: "#1C0A00" }}
          className="inline-flex items-center gap-2 px-8 py-4 rounded-full font-bold text-sm hover:scale-105 transition-transform shadow-lg">
          Shop Now
        </Link>
      </section>
    </div>
  );
}
