import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { User, Package, MapPin, Settings, LogOut, Edit3, Save, X, Shield, Clock } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getUserOrders } from "../services/db";

type Tab = "profile" | "orders" | "address" | "settings";

export default function Profile() {
  const { user, logout, updateProfile } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("profile");
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: user?.name || "", phone: user?.phone || "", address: user?.address || "", city: user?.city || "", pincode: user?.pincode || "" });
  const [saved, setSaved] = useState(false);

  if (!user) { navigate("/login"); return null; }

  const orders = getUserOrders(user.id).slice(0, 10);

  function handleSave() {
    updateProfile(form);
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const tabs = [
    { id: "profile" as Tab, icon: User, label: "My Profile" },
    { id: "orders" as Tab, icon: Package, label: "My Orders" },
    { id: "address" as Tab, icon: MapPin, label: "Addresses" },
    { id: "settings" as Tab, icon: Settings, label: "Settings" },
  ];

  const statusColors: Record<string, string> = {
    pending: "#D97706",
    confirmed: "#2563EB",
    processing: "#7C3AED",
    shipped: "#0891B2",
    delivered: "#16A34A",
    refund_requested: "#DC2626",
    refunded: "#6B7280",
    cancelled: "#DC2626",
  };

  return (
    <div className="min-h-screen py-8 px-4" style={{ background: "#FFF8F0" }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-orange-100 mb-6">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow"
              style={{ background: "linear-gradient(135deg, #C8421A, #D4A017)" }}>
              {user.name[0].toUpperCase()}
            </div>
            <div>
              <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-2xl font-bold text-gray-800">{user.name}</h1>
              <p className="text-sm text-gray-500">{user.email}</p>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-xs text-gray-400">📱 {user.phone}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold"
                  style={{ background: user.role === "admin" ? "#FEF3C7" : "#F0FDF4", color: user.role === "admin" ? "#92400E" : "#15803D" }}>
                  {user.role === "admin" ? "👑 Admin" : "✓ Member"}
                </span>
              </div>
            </div>
            <div className="ml-auto hidden md:flex gap-3">
              <div className="text-center px-4 py-2 bg-orange-50 rounded-xl">
                <div className="font-bold text-lg" style={{ color: "#C8421A" }}>{orders.length}</div>
                <div className="text-xs text-gray-500">Orders</div>
              </div>
              <div className="text-center px-4 py-2 bg-orange-50 rounded-xl">
                <div className="font-bold text-lg" style={{ color: "#C8421A" }}>₹{orders.reduce((s, o) => s + o.total, 0)}</div>
                <div className="text-xs text-gray-500">Spent</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-[220px_1fr] gap-6">
          {/* Sidebar */}
          <div className="space-y-1">
            <div className="bg-white rounded-2xl p-3 shadow-sm border border-orange-100">
              {tabs.map(tab => (
                <button key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === tab.id ? "text-white" : "text-gray-600 hover:bg-orange-50"}`}
                  style={activeTab === tab.id ? { background: "#C8421A" } : {}}>
                  <tab.icon size={16} /> {tab.label}
                </button>
              ))}
              <hr className="my-2 border-orange-100" />
              {user.role === "admin" && (
                <Link to="/admin"
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-yellow-700 hover:bg-yellow-50 transition-all">
                  <Shield size={16} /> Admin Panel
                </Link>
              )}
              <button onClick={() => { logout(); navigate("/"); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 transition-all">
                <LogOut size={16} /> Sign Out
              </button>
            </div>
          </div>

          {/* Main content */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-orange-100">
            {/* Profile tab */}
            {activeTab === "profile" && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-gray-800">Personal Information</h2>
                  {!editing ? (
                    <button onClick={() => setEditing(true)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border border-orange-200 hover:bg-orange-50 transition-colors" style={{ color: "#C8421A" }}>
                      <Edit3 size={14} /> Edit
                    </button>
                  ) : (
                    <div className="flex gap-2">
                      <button onClick={() => setEditing(false)} className="flex items-center gap-1 px-3 py-2 rounded-xl text-sm text-gray-500 hover:bg-gray-100 transition-colors">
                        <X size={14} /> Cancel
                      </button>
                      <button onClick={handleSave}
                        className="flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-medium text-white transition-colors" style={{ background: "#C8421A" }}>
                        <Save size={14} /> Save
                      </button>
                    </div>
                  )}
                </div>
                {saved && <div className="mb-4 p-3 rounded-xl bg-green-50 border border-green-200 text-sm text-green-700">✓ Profile updated successfully!</div>}
                <div className="grid md:grid-cols-2 gap-5">
                  {[
                    { label: "Full Name", key: "name", value: form.name },
                    { label: "Phone Number", key: "phone", value: form.phone },
                    { label: "Email Address", key: "email", value: user.email, readonly: true },
                    { label: "Member Since", key: "created", value: new Date(user.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "long", day: "numeric" }), readonly: true },
                  ].map(({ label, key, value, readonly }) => (
                    <div key={key}>
                      <label className="block text-xs font-medium text-gray-500 mb-1.5">{label}</label>
                      {editing && !readonly ? (
                        <input value={value} onChange={e => setForm({ ...form, [key]: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white" />
                      ) : (
                        <p className={`text-sm font-medium px-4 py-2.5 rounded-xl ${readonly ? "text-gray-400 bg-gray-50" : "text-gray-800"}`}>{value}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Orders tab */}
            {activeTab === "orders" && (
              <div>
                <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-gray-800 mb-6">My Orders</h2>
                {orders.length === 0 ? (
                  <div className="text-center py-12 text-gray-400">
                    <Package size={48} className="mx-auto mb-3 text-gray-200" />
                    <p className="font-medium">No orders yet</p>
                    <Link to="/products" style={{ color: "#C8421A" }} className="text-sm mt-2 block hover:underline">Start shopping</Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map(order => (
                      <div key={order.id} className="border border-orange-100 rounded-xl p-4 hover:shadow-sm transition-shadow">
                        <div className="flex flex-wrap justify-between items-start gap-3 mb-3">
                          <div>
                            <p className="font-semibold text-sm text-gray-800">{order.id}</p>
                            <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                              <Clock size={11} /> {new Date(order.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" })}
                            </p>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-xs font-bold px-2.5 py-1 rounded-full text-white"
                              style={{ background: statusColors[order.status] || "#6B7280" }}>
                              {order.status.replace(/_/g, " ").toUpperCase()}
                            </span>
                            <span className="font-bold text-sm" style={{ color: "#C8421A" }}>₹{order.total}</span>
                          </div>
                        </div>
                        <div className="flex gap-2 flex-wrap mb-3">
                          {order.items.map((item, i) => (
                            <img key={i} src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" title={item.name} />
                          ))}
                        </div>
                        <div className="flex gap-2">
                          {order.status === "delivered" && (
                            <button className="text-xs px-3 py-1.5 rounded-lg border border-orange-200 hover:bg-orange-50 transition-colors" style={{ color: "#C8421A" }}>
                              Request Refund
                            </button>
                          )}
                          <button className="text-xs px-3 py-1.5 rounded-lg bg-orange-50 hover:bg-orange-100 transition-colors" style={{ color: "#C8421A" }}>
                            View Details
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Address tab */}
            {activeTab === "address" && (
              <div>
                <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-gray-800 mb-6">Saved Addresses</h2>
                <div className="border border-orange-200 rounded-xl p-5 bg-orange-50/50 mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-xs font-bold text-orange-600 px-2 py-0.5 rounded-full bg-orange-100">DEFAULT</span>
                    <button onClick={() => setEditing(true)} style={{ color: "#C8421A" }} className="text-xs hover:underline">Edit</button>
                  </div>
                  <p className="text-sm font-semibold text-gray-800">{user.name}</p>
                  <p className="text-sm text-gray-600 mt-1">{user.address || "No address saved"}</p>
                  <p className="text-sm text-gray-600">{user.city} {user.pincode}</p>
                  <p className="text-xs text-gray-400 mt-2">📱 {user.phone}</p>
                </div>
                {(!user.address) && (
                  <button onClick={() => setActiveTab("profile")}
                    style={{ border: "2px dashed #C8421A", color: "#C8421A" }}
                    className="w-full py-4 rounded-xl text-sm font-medium hover:bg-orange-50 transition-colors">
                    + Add New Address
                  </button>
                )}
              </div>
            )}

            {/* Settings tab */}
            {activeTab === "settings" && (
              <div>
                <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-gray-800 mb-6">Account Settings</h2>
                <div className="space-y-4">
                  {[
                    { label: "Email Notifications", desc: "Receive order updates via email", default: true },
                    { label: "SMS Alerts", desc: "Get shipping and delivery alerts via SMS", default: true },
                    { label: "Promotional Offers", desc: "Receive exclusive discounts and festival offers", default: false },
                  ].map(setting => (
                    <div key={setting.label} className="flex items-center justify-between p-4 rounded-xl border border-orange-100 hover:bg-orange-50/50 transition-colors">
                      <div>
                        <p className="text-sm font-medium text-gray-800">{setting.label}</p>
                        <p className="text-xs text-gray-400">{setting.desc}</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked={setting.default} className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                      </label>
                    </div>
                  ))}
                  <div className="pt-4 border-t border-orange-100">
                    <button className="text-sm text-red-500 hover:text-red-700 font-medium">Delete Account</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
