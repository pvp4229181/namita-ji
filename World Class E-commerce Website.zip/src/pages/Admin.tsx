import { useState, useMemo } from "react";
import { Navigate } from "react-router-dom";
import { Users, Package, DollarSign, TrendingUp, Search, Filter, RefreshCw, Check, X, Eye, ChevronDown } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getAllOrders, getAllUsers, updateOrder, Order } from "../services/db";

type OrderStatus = Order["status"];

const statusOptions: OrderStatus[] = ["pending", "confirmed", "processing", "shipped", "delivered", "refund_requested", "refunded", "cancelled"];

const statusColors: Record<string, string> = {
  pending: "#92400E",
  confirmed: "#1E40AF",
  processing: "#5B21B6",
  shipped: "#164E63",
  delivered: "#065F46",
  refund_requested: "#991B1B",
  refunded: "#374151",
  cancelled: "#991B1B",
};

const statusBg: Record<string, string> = {
  pending: "#FEF3C7",
  confirmed: "#DBEAFE",
  processing: "#EDE9FE",
  shipped: "#CFFAFE",
  delivered: "#D1FAE5",
  refund_requested: "#FEE2E2",
  refunded: "#F3F4F6",
  cancelled: "#FEE2E2",
};

export default function Admin() {
  const { user, isAdmin } = useAuth();
  if (!user || !isAdmin) return <Navigate to="/" />;

  const [orders, setOrders] = useState(getAllOrders());
  const [users] = useState(getAllUsers());
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [activeTab, setActiveTab] = useState<"orders" | "users" | "analytics">("orders");

  const totalRevenue = orders.filter(o => o.paymentStatus === "paid").reduce((s, o) => s + o.total, 0);
  const pendingRefunds = orders.filter(o => o.status === "refund_requested").length;
  const todayOrders = orders.filter(o => new Date(o.createdAt).toDateString() === new Date().toDateString()).length;

  const filtered = useMemo(() => {
    let list = [...orders];
    if (search) list = list.filter(o => o.id.toLowerCase().includes(search.toLowerCase()) || o.userName.toLowerCase().includes(search.toLowerCase()) || o.userEmail.toLowerCase().includes(search.toLowerCase()));
    if (statusFilter !== "all") list = list.filter(o => o.status === statusFilter);
    return list;
  }, [orders, search, statusFilter]);

  function handleStatusChange(orderId: string, status: OrderStatus) {
    const updated = updateOrder(orderId, { status, paymentStatus: status === "refunded" ? "refunded" : undefined });
    if (updated) {
      setOrders(prev => prev.map(o => o.id === updated.id ? updated : o));
      if (selectedOrder?.id === updated.id) setSelectedOrder(updated);
    }
  }

  const stats = [
    { label: "Total Revenue", value: `₹${totalRevenue.toLocaleString("en-IN")}`, icon: DollarSign, color: "#16a34a", bg: "#D1FAE5" },
    { label: "Total Orders", value: orders.length.toString(), icon: Package, color: "#2563EB", bg: "#DBEAFE" },
    { label: "Registered Users", value: users.filter(u => u.role !== "admin").length.toString(), icon: Users, color: "#7C3AED", bg: "#EDE9FE" },
    { label: "Pending Refunds", value: pendingRefunds.toString(), icon: RefreshCw, color: "#DC2626", bg: "#FEE2E2" },
  ];

  return (
    <div className="min-h-screen" style={{ background: "#F5EDE0" }}>
      {/* Admin header */}
      <div style={{ background: "#1C0A00" }} className="px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-orange-500 flex items-center justify-center">
            <span style={{ fontFamily: "'Playfair Display', serif", fontWeight: 800, fontSize: "13px" }} className="text-white">BT</span>
          </div>
          <div>
            <span style={{ fontFamily: "'Playfair Display', serif" }} className="text-white font-bold text-lg">Admin Panel</span>
            <span className="text-orange-400 text-xs ml-3">Bihari Thekua Online</span>
          </div>
        </div>
        <div className="text-sm text-gray-400">
          Welcome, <span className="text-orange-300 font-medium">{user.name}</span>
        </div>
      </div>

      <div className="px-6 py-8 max-w-7xl mx-auto">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map(({ label, value, icon: Icon, color, bg }) => (
            <div key={label} className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">{label}</span>
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: bg }}>
                  <Icon size={18} style={{ color }} />
                </div>
              </div>
              <p className="text-2xl font-bold text-gray-800">{value}</p>
            </div>
          ))}
        </div>

        {/* Quick insight */}
        <div className="bg-white rounded-2xl p-4 mb-6 shadow-sm border border-orange-100 flex flex-wrap items-center gap-6 text-sm">
          <div className="flex items-center gap-2 text-gray-600">
            <TrendingUp size={16} style={{ color: "#C8421A" }} />
            <span>Today's orders: <strong>{todayOrders}</strong></span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <span>Paid orders: <strong className="text-green-600">{orders.filter(o => o.paymentStatus === "paid").length}</strong></span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <span>Refund requests: <strong className="text-red-600">{pendingRefunds}</strong></span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {[{ id: "orders", label: "Orders" }, { id: "users", label: "Users" }, { id: "analytics", label: "Analytics" }].map(tab => (
            <button key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${activeTab === tab.id ? "text-white shadow" : "bg-white text-gray-600 hover:bg-orange-50 border border-orange-100"}`}
              style={activeTab === tab.id ? { background: "#C8421A" } : {}}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Orders table */}
        {activeTab === "orders" && (
          <div className="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
            {/* Toolbar */}
            <div className="px-5 py-4 border-b border-orange-100 flex flex-wrap gap-3 items-center">
              <div className="flex-1 relative min-w-48">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Search orders, customers..."
                  className="w-full pl-9 pr-4 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
              </div>
              <div className="flex items-center gap-2">
                <Filter size={15} className="text-gray-400" />
                <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-gray-200 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-orange-400">
                  <option value="all">All Status</option>
                  {statusOptions.map(s => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
                </select>
              </div>
              <span className="text-xs text-gray-400">{filtered.length} orders</span>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: "#FFF8F0" }}>
                    {["Order ID", "Customer", "Amount", "Items", "Payment", "Status", "Date", "Actions"].map(h => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr><td colSpan={8} className="text-center py-12 text-gray-400">No orders found</td></tr>
                  ) : filtered.map(order => (
                    <tr key={order.id} className="border-t border-orange-50 hover:bg-orange-50/50 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-gray-700 font-medium">{order.id}</td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-800">{order.userName}</div>
                        <div className="text-xs text-gray-400">{order.userEmail}</div>
                        <div className="text-xs text-gray-400">📱 {order.userPhone}</div>
                      </td>
                      <td className="px-4 py-3 font-bold" style={{ color: "#C8421A" }}>₹{order.total}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          {order.items.slice(0, 3).map((item, i) => (
                            <img key={i} src={item.image} alt={item.name} className="w-8 h-8 rounded-lg object-cover" title={`${item.name} ×${item.quantity}`} />
                          ))}
                          {order.items.length > 3 && <span className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-xs text-gray-500">+{order.items.length - 3}</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${order.paymentStatus === "paid" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>
                          {order.paymentStatus.toUpperCase()}
                        </span>
                        {order.paymentId && <div className="text-[10px] text-gray-400 mt-0.5 font-mono">{order.paymentId.slice(0, 12)}…</div>}
                      </td>
                      <td className="px-4 py-3">
                        <div className="relative group">
                          <button className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer"
                            style={{ background: statusBg[order.status] || "#F3F4F6", color: statusColors[order.status] || "#374151" }}>
                            {order.status.replace(/_/g, " ")} <ChevronDown size={11} />
                          </button>
                          <div className="absolute left-0 top-full mt-1 hidden group-hover:block z-10 bg-white rounded-xl shadow-xl border border-orange-100 py-1 min-w-48">
                            {statusOptions.map(s => (
                              <button key={s} onClick={() => handleStatusChange(order.id, s)}
                                className="w-full text-left px-4 py-2 text-xs hover:bg-orange-50 transition-colors flex items-center gap-2">
                                {order.status === s && <Check size={12} style={{ color: "#C8421A" }} />}
                                <span className="font-medium" style={{ color: statusColors[s] }}>{s.replace(/_/g, " ")}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">
                        {new Date(order.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                      </td>
                      <td className="px-4 py-3">
                        <button onClick={() => setSelectedOrder(selectedOrder?.id === order.id ? null : order)}
                          className="p-1.5 rounded-lg hover:bg-orange-100 transition-colors" style={{ color: "#C8421A" }}>
                          <Eye size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Users table */}
        {activeTab === "users" && (
          <div className="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
            <div className="px-5 py-4 border-b border-orange-100">
              <h3 className="font-semibold text-gray-800">Registered Users ({users.filter(u => u.role !== "admin").length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: "#FFF8F0" }}>
                    {["Name", "Email", "Phone", "City", "Orders", "Joined", "Role"].map(h => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => {
                    const userOrders = orders.filter(o => o.userId === u.id);
                    return (
                      <tr key={u.id} className="border-t border-orange-50 hover:bg-orange-50/50 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: "#C8421A" }}>
                              {u.name[0].toUpperCase()}
                            </div>
                            <span className="font-medium text-gray-800">{u.name}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-gray-600">{u.email}</td>
                        <td className="px-4 py-3 text-gray-600">{u.phone}</td>
                        <td className="px-4 py-3 text-gray-600">{u.city || "—"}</td>
                        <td className="px-4 py-3">
                          <span className="font-bold" style={{ color: "#C8421A" }}>{userOrders.length}</span>
                          {userOrders.length > 0 && (
                            <span className="text-xs text-gray-400 ml-1">(₹{userOrders.reduce((s, o) => s + o.total, 0)})</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-xs text-gray-500">
                          {new Date(u.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${u.role === "admin" ? "bg-yellow-100 text-yellow-700" : "bg-blue-50 text-blue-600"}`}>
                            {u.role}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Analytics */}
        {activeTab === "analytics" && (
          <div className="grid md:grid-cols-2 gap-5">
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100">
              <h3 className="font-semibold text-gray-800 mb-4">Revenue Breakdown</h3>
              <div className="space-y-3">
                {["Thekua", "Laddoo", "Gift Boxes", "Khaja", "Tilkut"].map((cat, i) => {
                  const pct = [45, 20, 25, 6, 4][i];
                  return (
                    <div key={cat}>
                      <div className="flex justify-between text-xs text-gray-600 mb-1">
                        <span>{cat}</span><span>{pct}%</span>
                      </div>
                      <div className="h-2 bg-orange-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: "#C8421A" }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100">
              <h3 className="font-semibold text-gray-800 mb-4">Order Status Summary</h3>
              <div className="space-y-2">
                {statusOptions.map(status => {
                  const count = orders.filter(o => o.status === status).length;
                  return (
                    <div key={status} className="flex items-center justify-between py-2 border-b border-orange-50">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold"
                        style={{ background: statusBg[status], color: statusColors[status] }}>
                        {status.replace(/_/g, " ")}
                      </span>
                      <span className="font-bold text-gray-700">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100 md:col-span-2">
              <h3 className="font-semibold text-gray-800 mb-4">Payment Summary</h3>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: "Total Collected", value: `₹${orders.filter(o => o.paymentStatus === "paid").reduce((s, o) => s + o.total, 0).toLocaleString("en-IN")}`, color: "#16a34a" },
                  { label: "Failed Payments", value: orders.filter(o => o.paymentStatus === "failed").length.toString(), color: "#DC2626" },
                  { label: "Refunds Processed", value: `₹${orders.filter(o => o.paymentStatus === "refunded").reduce((s, o) => s + o.total, 0).toLocaleString("en-IN")}`, color: "#6B7280" },
                ].map(({ label, value, color }) => (
                  <div key={label} className="text-center p-4 rounded-xl bg-orange-50">
                    <p className="text-2xl font-bold mb-1" style={{ color }}>{value}</p>
                    <p className="text-xs text-gray-500">{label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Order detail drawer */}
        {selectedOrder && (
          <div className="fixed inset-0 bg-black/40 z-50 flex justify-end" onClick={() => setSelectedOrder(null)}>
            <div className="bg-white w-full max-w-md h-full overflow-y-auto shadow-2xl fade-in" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-center px-5 py-4 border-b border-orange-100" style={{ background: "#C8421A" }}>
                <div>
                  <p style={{ fontFamily: "'Playfair Display', serif" }} className="text-white font-bold text-lg">Order Details</p>
                  <p className="text-orange-200 text-xs">{selectedOrder.id}</p>
                </div>
                <button onClick={() => setSelectedOrder(null)} className="text-white hover:bg-white/20 p-1.5 rounded-full"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div className="p-4 bg-orange-50 rounded-xl">
                  <p className="font-semibold text-gray-800">{selectedOrder.userName}</p>
                  <p className="text-sm text-gray-500">{selectedOrder.userEmail}</p>
                  <p className="text-sm text-gray-500">📱 {selectedOrder.userPhone}</p>
                  <p className="text-sm text-gray-500 mt-1">📍 {selectedOrder.address}, {selectedOrder.city} — {selectedOrder.pincode}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm text-gray-700 mb-2">Items</h4>
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="flex gap-3 items-center py-2 border-b border-orange-50">
                      <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-xs text-gray-400">{item.weight} × {item.quantity}</p>
                      </div>
                      <span className="text-sm font-bold" style={{ color: "#C8421A" }}>₹{item.price * item.quantity}</span>
                    </div>
                  ))}
                </div>
                <div className="p-4 bg-gray-50 rounded-xl space-y-1.5 text-sm">
                  <div className="flex justify-between"><span className="text-gray-500">Subtotal</span><span>₹{selectedOrder.subtotal}</span></div>
                  {selectedOrder.couponCode && <div className="flex justify-between text-green-600"><span>Coupon</span><span>-₹{selectedOrder.discount}</span></div>}
                  <div className="flex justify-between"><span className="text-gray-500">Delivery</span><span>{selectedOrder.deliveryCharge === 0 ? "FREE" : `₹${selectedOrder.deliveryCharge}`}</span></div>
                  <div className="flex justify-between font-bold pt-1 border-t" style={{ color: "#C8421A" }}><span>Total</span><span>₹{selectedOrder.total}</span></div>
                </div>
                {selectedOrder.paymentId && (
                  <div className="text-xs text-gray-500 font-mono bg-gray-50 p-3 rounded-xl">
                    💳 {selectedOrder.paymentId}
                  </div>
                )}
                {selectedOrder.refundReason && (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-xl">
                    <p className="text-xs font-semibold text-red-700 mb-1">Refund Reason</p>
                    <p className="text-sm text-red-600">{selectedOrder.refundReason}</p>
                  </div>
                )}
                <div>
                  <label className="block text-xs font-medium text-gray-500 mb-2">Update Status</label>
                  <select value={selectedOrder.status}
                    onChange={e => handleStatusChange(selectedOrder.id, e.target.value as OrderStatus)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400">
                    {statusOptions.map(s => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
