import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { X, Trash2, Plus, Minus, Tag, XCircle, ChevronRight, ShoppingBag } from "lucide-react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";

export default function CartSidebar() {
  const {
    items, isCartOpen, closeCart, removeFromCart, updateQuantity,
    subtotal, discount, deliveryCharge, total, totalItems,
    appliedCoupon, couponDiscount, applyCoupon, removeCoupon,
  } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [couponInput, setCouponInput] = useState("");
  const [couponMsg, setCouponMsg] = useState<{ text: string; ok: boolean } | null>(null);

  if (!isCartOpen) return null;

  function handleApplyCoupon() {
    if (!couponInput.trim()) return;
    const result = applyCoupon(couponInput.trim());
    setCouponMsg({ text: result.message, ok: result.success });
    if (result.success) setCouponInput("");
  }

  function handleRemoveCoupon() {
    removeCoupon();
    setCouponMsg(null);
    setCouponInput("");
  }

  function handleCheckout() {
    closeCart();
    if (!user) {
      navigate("/login?redirect=/checkout");
    } else {
      navigate("/checkout");
    }
  }

  const savings = discount + couponDiscount;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50 z-50" onClick={closeCart} />

      {/* Drawer */}
      <div className="fixed top-0 right-0 h-full w-full max-w-[420px] bg-white z-50 flex flex-col shadow-2xl cart-slide">
        {/* Header */}
        <div style={{ background: "#C8421A" }} className="px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShoppingBag size={20} className="text-white" />
            <span style={{ fontFamily: "'Playfair Display', serif" }} className="text-white font-bold text-lg">
              My Cart
            </span>
            {totalItems > 0 && (
              <span className="bg-yellow-400 text-red-900 text-xs font-bold px-2 py-0.5 rounded-full">{totalItems}</span>
            )}
          </div>
          <button onClick={closeCart} className="p-1.5 text-white hover:bg-white/20 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 px-6 text-center">
            <div className="w-24 h-24 rounded-full bg-orange-50 flex items-center justify-center">
              <ShoppingBag size={40} className="text-orange-300" />
            </div>
            <div>
              <p style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-semibold text-gray-700 mb-1">Your cart is empty</p>
              <p className="text-sm text-gray-400">Add some delicious Bihari sweets!</p>
            </div>
            <button onClick={() => { closeCart(); navigate("/products"); }}
              style={{ background: "#C8421A" }}
              className="px-6 py-2.5 rounded-full text-white text-sm font-medium hover:opacity-90 transition-opacity">
              Shop Now
            </button>
          </div>
        ) : (
          <>
            {/* Free delivery progress */}
            {subtotal < 499 && (
              <div className="px-4 py-2.5 bg-orange-50 border-b border-orange-100">
                <div className="flex justify-between text-xs text-gray-600 mb-1.5">
                  <span>Add ₹{499 - subtotal} more for free delivery</span>
                  <span className="font-medium">₹499</span>
                </div>
                <div className="h-1.5 bg-orange-200 rounded-full overflow-hidden">
                  <div style={{ width: `${Math.min((subtotal / 499) * 100, 100)}%`, background: "#C8421A" }} className="h-full rounded-full transition-all duration-500" />
                </div>
              </div>
            )}
            {subtotal >= 499 && (
              <div className="px-4 py-2 bg-green-50 border-b border-green-100 text-xs text-green-700 font-medium">
                🎉 You qualify for FREE delivery!
              </div>
            )}

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
              {items.map(item => (
                <div key={item.id} className="flex gap-3 p-3 bg-orange-50/50 rounded-xl border border-orange-100">
                  <img src={item.image} alt={item.name} className="w-16 h-16 rounded-lg object-cover flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm font-semibold text-gray-800 leading-tight truncate pr-2">{item.name}</p>
                        <p className="text-xs text-gray-500 mt-0.5">{item.weight}</p>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="text-gray-300 hover:text-red-500 transition-colors flex-shrink-0">
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-bold" style={{ color: "#C8421A" }}>₹{item.price}</span>
                        <span className="text-xs text-gray-400 line-through">₹{item.originalPrice}</span>
                      </div>
                      {/* Qty controls */}
                      <div className="flex items-center gap-2 border border-orange-200 rounded-full px-2 py-0.5 bg-white">
                        <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="text-orange-600 hover:text-orange-800 transition-colors">
                          <Minus size={13} />
                        </button>
                        <span className="text-sm font-semibold w-4 text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="text-orange-600 hover:text-orange-800 transition-colors">
                          <Plus size={13} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Coupon section */}
            <div className="px-4 py-3 border-t border-orange-100">
              {appliedCoupon ? (
                <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <Tag size={15} className="text-green-600" />
                    <div>
                      <span className="text-sm font-semibold text-green-700">{appliedCoupon}</span>
                      <p className="text-xs text-green-600">You save ₹{couponDiscount}!</p>
                    </div>
                  </div>
                  <button onClick={handleRemoveCoupon} className="flex items-center gap-1 text-xs text-red-500 hover:text-red-700 font-medium transition-colors">
                    <XCircle size={15} /> Remove
                  </button>
                </div>
              ) : (
                <div>
                  <div className="flex gap-2">
                    <div className="flex-1 flex items-center gap-2 border border-orange-200 rounded-xl px-3 py-2 bg-white">
                      <Tag size={15} className="text-orange-400" />
                      <input
                        value={couponInput}
                        onChange={e => { setCouponInput(e.target.value.toUpperCase()); setCouponMsg(null); }}
                        placeholder="Enter coupon code"
                        className="flex-1 text-sm focus:outline-none bg-transparent"
                        onKeyDown={e => e.key === "Enter" && handleApplyCoupon()}
                      />
                    </div>
                    <button
                      onClick={handleApplyCoupon}
                      style={{ background: "#C8421A" }}
                      className="px-4 py-2 rounded-xl text-white text-sm font-medium hover:opacity-90 transition-opacity whitespace-nowrap"
                    >
                      Apply
                    </button>
                  </div>
                  {couponMsg && (
                    <p className={`text-xs mt-1.5 px-1 ${couponMsg.ok ? "text-green-600" : "text-red-500"}`}>{couponMsg.text}</p>
                  )}
                  <p className="text-xs text-gray-400 mt-1.5 px-1">Try: WELCOME10, CHHATH20, FLAT100</p>
                </div>
              )}
            </div>

            {/* Price summary */}
            <div className="px-4 py-3 border-t border-orange-100 bg-orange-50/50 space-y-1.5 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span><span>₹{subtotal}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Product Savings</span><span>-₹{discount}</span>
                </div>
              )}
              {couponDiscount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Coupon ({appliedCoupon})</span><span>-₹{couponDiscount}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-600">
                <span>Delivery</span>
                <span>{deliveryCharge === 0 ? <span className="text-green-600 font-medium">FREE</span> : `₹${deliveryCharge}`}</span>
              </div>
              {savings > 0 && (
                <div className="pt-1 border-t border-dashed border-orange-200 text-xs text-green-700 font-medium">
                  🎉 Total savings: ₹{savings + (deliveryCharge === 0 && subtotal >= 499 ? 60 : 0)}
                </div>
              )}
              <div className="flex justify-between font-bold text-base pt-1 border-t border-orange-200" style={{ color: "#C8421A" }}>
                <span>Total</span><span>₹{total}</span>
              </div>
            </div>

            {/* Checkout button */}
            <div className="px-4 pb-4 pt-2">
              <button
                onClick={handleCheckout}
                style={{ background: "#C8421A" }}
                className="w-full py-3.5 rounded-full text-white font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity shadow-lg shadow-orange-200"
              >
                Proceed to Checkout <ChevronRight size={18} />
              </button>
              <p className="text-center text-xs text-gray-400 mt-2">🔒 Secure checkout powered by Razorpay</p>
            </div>
          </>
        )}
      </div>
    </>
  );
}
