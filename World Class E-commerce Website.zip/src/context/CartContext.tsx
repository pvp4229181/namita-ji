import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Product } from "../data/products";
import { coupons } from "../data/products";

export interface CartItem extends Product {
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, qty: number) => void;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;
  discount: number;
  deliveryCharge: number;
  total: number;
  appliedCoupon: string | null;
  couponDiscount: number;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
}

const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try { return JSON.parse(localStorage.getItem("bihari_cart") || "[]"); }
    catch { return []; }
  });
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem("bihari_cart", JSON.stringify(items));
  }, [items]);

  function addToCart(product: Product) {
    setItems(prev => {
      const existing = prev.find(i => i.id === product.id);
      if (existing) return prev.map(i => i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  }

  function removeFromCart(id: string) {
    setItems(prev => prev.filter(i => i.id !== id));
  }

  function updateQuantity(id: string, qty: number) {
    if (qty <= 0) { removeFromCart(id); return; }
    setItems(prev => prev.map(i => i.id === id ? { ...i, quantity: qty } : i));
  }

  function clearCart() {
    setItems([]);
    setAppliedCoupon(null);
  }

  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const deliveryCharge = subtotal >= 499 ? 0 : 60;

  let couponDiscount = 0;
  if (appliedCoupon && coupons[appliedCoupon]) {
    const c = coupons[appliedCoupon];
    if (c.type === "percent") couponDiscount = Math.floor(subtotal * c.discount / 100);
    else couponDiscount = Math.min(c.discount, subtotal);
  }

  const discount = items.reduce((sum, i) => sum + (i.originalPrice - i.price) * i.quantity, 0);
  const total = subtotal - couponDiscount + deliveryCharge;

  function applyCoupon(code: string) {
    const c = coupons[code.toUpperCase()];
    if (!c) return { success: false, message: "Invalid coupon code." };
    if (subtotal < c.minOrder) return { success: false, message: `Minimum order of ₹${c.minOrder} required.` };
    setAppliedCoupon(code.toUpperCase());
    return { success: true, message: `Coupon applied! You save ₹${c.type === "percent" ? Math.floor(subtotal * c.discount / 100) : c.discount}.` };
  }

  function removeCoupon() {
    setAppliedCoupon(null);
  }

  return (
    <CartContext.Provider value={{
      items, addToCart, removeFromCart, updateQuantity, clearCart,
      totalItems: items.reduce((s, i) => s + i.quantity, 0),
      subtotal, discount, deliveryCharge, total,
      appliedCoupon, couponDiscount,
      applyCoupon, removeCoupon,
      isCartOpen, openCart: () => setIsCartOpen(true), closeCart: () => setIsCartOpen(false),
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
