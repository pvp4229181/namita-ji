import { Link } from "react-router-dom";
import { MapPin, Phone, Mail, ExternalLink } from "lucide-react";

export default function Footer() {
  return (
    <footer style={{ background: "#1C0A00" }} className="text-white">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-6 py-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-11 h-11 rounded-full bg-orange-500 flex items-center justify-center">
              <span style={{ fontFamily: "'Playfair Display', serif", fontWeight: 800, fontSize: "15px" }}>BT</span>
            </div>
            <div>
              <div style={{ fontFamily: "'Playfair Display', serif" }} className="font-bold text-lg leading-tight">Bihari Thekua</div>
              <div className="text-orange-300 text-[10px] uppercase tracking-widest">Authentic Taste of Bihar</div>
            </div>
          </div>
          <p className="text-gray-400 text-sm leading-relaxed mb-5">
            Handcrafted with love using traditional Bihar recipes. No preservatives, no artificial colours. Just pure, authentic flavours from our family to yours.
          </p>
          <div className="flex gap-3">
            {["f", "in", "yt", "tw"].map((label, i) => (
              <a key={i} href="#" className="w-8 h-8 rounded-full bg-white/10 hover:bg-orange-600 flex items-center justify-center transition-colors text-[10px] font-bold">
                {label}
              </a>
            ))}
          </div>
          <div className="mt-5 flex flex-wrap gap-2">
            {["FSSAI Certified", "No Preservatives", "Pure Ghee"].map(tag => (
              <span key={tag} className="px-2.5 py-1 rounded-full text-[10px] font-medium" style={{ background: "#C8421A20", color: "#F0C040", border: "1px solid #C8421A40" }}>{tag}</span>
            ))}
          </div>
        </div>

        {/* Quick links */}
        <div>
          <h4 style={{ fontFamily: "'Playfair Display', serif" }} className="font-semibold text-base mb-4 text-orange-300">Quick Links</h4>
          <ul className="space-y-2.5 text-sm text-gray-400">
            {[
              { label: "Home", path: "/" },
              { label: "Shop All", path: "/products" },
              { label: "Thekua", path: "/products?category=Thekua" },
              { label: "Laddoo", path: "/products?category=Laddoo" },
              { label: "Gift Boxes", path: "/products?category=Gift+Boxes" },
              { label: "About Us", path: "/about" },
            ].map(({ label, path }) => (
              <li key={label}>
                <Link to={path} className="hover:text-orange-400 transition-colors flex items-center gap-1.5">
                  <span className="text-orange-600">›</span> {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Customer care */}
        <div>
          <h4 style={{ fontFamily: "'Playfair Display', serif" }} className="font-semibold text-base mb-4 text-orange-300">Customer Care</h4>
          <ul className="space-y-2.5 text-sm text-gray-400">
            {[
              { label: "My Account", path: "/profile" },
              { label: "My Orders", path: "/orders" },
              { label: "Track Order", path: "/orders" },
              { label: "Returns & Refunds", path: "/orders" },
              { label: "FAQs", path: "/#faq" },
              { label: "Privacy Policy", path: "#" },
              { label: "Terms & Conditions", path: "#" },
            ].map(({ label, path }) => (
              <li key={label}>
                <Link to={path} className="hover:text-orange-400 transition-colors flex items-center gap-1.5">
                  <span className="text-orange-600">›</span> {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 style={{ fontFamily: "'Playfair Display', serif" }} className="font-semibold text-base mb-4 text-orange-300">Get In Touch</h4>
          <ul className="space-y-3 text-sm text-gray-400">
            <li className="flex gap-3 items-start">
              <MapPin size={15} className="text-orange-500 mt-0.5 flex-shrink-0" />
              <span>Bihar Bhawan, Boring Road, Patna — 800001, Bihar, India</span>
            </li>
            <li className="flex gap-3 items-center">
              <Phone size={15} className="text-orange-500" />
              <a href="tel:+919876543210" className="hover:text-orange-400 transition-colors">+91 98765 43210</a>
            </li>
            <li className="flex gap-3 items-center">
              <Mail size={15} className="text-orange-500" />
              <a href="mailto:hello@biharithekua.com" className="hover:text-orange-400 transition-colors">hello@biharithekua.com</a>
            </li>
          </ul>
          {/* Newsletter */}
          <div className="mt-6">
            <p className="text-xs text-gray-400 mb-2">Get offers & updates in your inbox</p>
            <div className="flex gap-2">
              <input placeholder="Your email" className="flex-1 px-3 py-2 rounded-lg bg-white/10 text-white placeholder-gray-500 text-xs border border-white/10 focus:outline-none focus:border-orange-500" />
              <button style={{ background: "#C8421A" }} className="px-4 py-2 rounded-lg text-white text-xs font-medium hover:opacity-90 transition-opacity whitespace-nowrap">Subscribe</button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-gray-500">
          <span>© {new Date().getFullYear()} Bihari Thekua Online. All rights reserved.</span>
          <div className="flex items-center gap-2">
            <span>Secure payments by</span>
            <span className="font-semibold text-gray-400">Razorpay</span>
            <span>•</span>
            <span>🏅 FSSAI Certified</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
