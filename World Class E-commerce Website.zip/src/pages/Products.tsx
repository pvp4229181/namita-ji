import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { products, categories } from "../data/products";
import { useCart } from "../context/CartContext";
import { Star, Plus, SlidersHorizontal, X } from "lucide-react";

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <Star key={s} size={11} className={s <= Math.round(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"} />
      ))}
    </div>
  );
}

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { addToCart } = useCart();
  const [addedId, setAddedId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState("popular");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000]);
  const [filterOpen, setFilterOpen] = useState(false);

  const categoryParam = searchParams.get("category") || "All";
  const searchQuery = searchParams.get("q") || "";

  function handleAdd(product: typeof products[0]) {
    addToCart(product);
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 1500);
  }

  const filtered = useMemo(() => {
    let list = [...products];
    if (categoryParam !== "All") list = list.filter(p => p.category === categoryParam);
    if (searchQuery) list = list.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.description.toLowerCase().includes(searchQuery.toLowerCase()));
    list = list.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);
    if (sortBy === "price-asc") list.sort((a, b) => a.price - b.price);
    else if (sortBy === "price-desc") list.sort((a, b) => b.price - a.price);
    else if (sortBy === "rating") list.sort((a, b) => b.rating - a.rating);
    else list.sort((a, b) => b.reviews - a.reviews);
    return list;
  }, [categoryParam, searchQuery, sortBy, priceRange]);

  return (
    <div className="min-h-screen" style={{ background: "#FFF8F0" }}>
      {/* Page header */}
      <div style={{ background: "linear-gradient(135deg, #8B1A1A 0%, #C8421A 100%)" }} className="py-12 px-6 text-center text-white">
        <p className="text-yellow-400 text-xs font-medium uppercase tracking-widest mb-2">Our Collection</p>
        <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl md:text-4xl font-bold">
          {searchQuery ? `Search: "${searchQuery}"` : categoryParam === "All" ? "All Products" : categoryParam}
        </h1>
        <p className="text-orange-200 text-sm mt-2">{filtered.length} products</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        {/* Toolbar */}
        <div className="flex flex-wrap gap-3 items-center justify-between mb-6">
          {/* Category pills */}
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button key={cat}
                onClick={() => setSearchParams(cat === "All" ? {} : { category: cat })}
                className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all ${categoryParam === cat ? "text-white shadow" : "text-gray-600 hover:bg-orange-100"}`}
                style={categoryParam === cat ? { background: "#C8421A" } : { background: "white", border: "1px solid #E5D5C5" }}>
                {cat}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-orange-200 text-sm text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-orange-400">
              <option value="popular">Most Popular</option>
              <option value="rating">Top Rated</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
            <button onClick={() => setFilterOpen(!filterOpen)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-orange-200 text-sm text-gray-700 bg-white hover:bg-orange-50 transition-colors">
              <SlidersHorizontal size={14} /> Filters
            </button>
          </div>
        </div>

        {/* Filter panel */}
        {filterOpen && (
          <div className="bg-white rounded-xl p-5 mb-6 border border-orange-100 shadow-sm fade-in">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-sm text-gray-800">Filters</h3>
              <button onClick={() => setFilterOpen(false)}><X size={16} className="text-gray-400" /></button>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600 mb-2 block">Price Range: ₹{priceRange[0]} — ₹{priceRange[1]}</label>
              <div className="flex items-center gap-4">
                <input type="range" min={0} max={2000} step={50} value={priceRange[1]}
                  onChange={e => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  className="flex-1 accent-orange-600" />
                <span className="text-sm font-medium text-gray-700 w-16">₹{priceRange[1]}</span>
              </div>
            </div>
          </div>
        )}

        {/* Grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            <div className="text-5xl mb-4">🔍</div>
            <p className="font-medium">No products found</p>
            <button onClick={() => setSearchParams({})} className="mt-4 text-sm" style={{ color: "#C8421A" }}>Clear filters</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map(product => (
              <div key={product.id}
                className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group border border-orange-100">
                <div className="relative overflow-hidden">
                  <img src={product.image} alt={product.name}
                    className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-500" />
                  {product.badge && (
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold text-white shadow"
                      style={{ background: "#C8421A" }}>{product.badge}</span>
                  )}
                  <div className="absolute top-3 right-3 bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                    {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                  </div>
                  {!product.inStock && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <span className="bg-white text-gray-700 px-4 py-1.5 rounded-full text-sm font-bold">Sold Out</span>
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <p className="text-xs text-gray-400 font-medium uppercase tracking-wide mb-1">{product.category} · {product.weight}</p>
                  <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="font-bold text-gray-800 text-base mb-1 leading-tight">{product.name}</h3>
                  <p className="text-xs text-gray-500 mb-3 line-clamp-2">{product.description}</p>
                  <div className="flex items-center gap-2 mb-3">
                    <StarRating rating={product.rating} />
                    <span className="text-xs text-gray-400">({product.reviews})</span>
                  </div>
                  {/* Ingredients preview */}
                  <p className="text-[10px] text-gray-400 mb-3 truncate">🌿 {product.ingredients}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-lg font-bold" style={{ color: "#C8421A" }}>₹{product.price}</span>
                      <span className="text-sm text-gray-400 line-through ml-1.5">₹{product.originalPrice}</span>
                    </div>
                    <button
                      disabled={!product.inStock}
                      onClick={() => handleAdd(product)}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-sm font-medium transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                      style={{ background: addedId === product.id ? "#16a34a" : "#C8421A", color: "white" }}>
                      {addedId === product.id ? "Added ✓" : <><Plus size={14} /> Add</>}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
