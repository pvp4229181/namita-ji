import { Link } from "react-router-dom";
import { ShoppingCart, Star, Truck, Shield, Clock, Award, ChevronRight, Plus } from "lucide-react";
import { products, categories } from "../data/products";
import { useCart } from "../context/CartContext";
import { useState } from "react";

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <Star key={s} size={12} className={s <= Math.round(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"} />
      ))}
    </div>
  );
}

export default function Home() {
  const { addToCart } = useCart();
  const [activeCategory, setActiveCategory] = useState("All");
  const [addedId, setAddedId] = useState<string | null>(null);
  const featured = products.slice(0, 8);
  const filtered = activeCategory === "All" ? featured : featured.filter(p => p.category === activeCategory);

  function handleAdd(product: typeof products[0]) {
    addToCart(product);
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 1500);
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden heritage-pattern" style={{ background: "linear-gradient(135deg, #8B1A1A 0%, #C8421A 50%, #9E3214 100%)" }}>
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1601050690597-df0568f70950?w=1400&auto=format')", backgroundSize: "cover", backgroundPosition: "center" }} />
        <div className="relative max-w-7xl mx-auto px-6 py-20 md:py-28 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="fade-in">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium mb-6"
              style={{ background: "#D4A01720", border: "1px solid #D4A01750", color: "#F0C040" }}>
              <span>🏅</span> FSSAI Certified · No Preservatives · Pan-India Shipping
            </div>
            <h1 style={{ fontFamily: "'Playfair Display', serif" }}
              className="text-4xl md:text-6xl font-bold text-white leading-tight mb-5">
              Authentic Taste of<br />
              <span style={{ color: "#F0C040" }}>Bihar</span> — Delivered Fresh
            </h1>
            <p className="text-orange-200 text-base md:text-lg leading-relaxed mb-8 max-w-xl">
              Handcrafted Thekua, Laddoo, Khaja and more — made with pure desi ghee and jaggery using recipes passed down through generations. Order now, savour heritage.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/products"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-sm transition-all hover:scale-105"
                style={{ background: "#D4A017", color: "#1C0A00" }}>
                Shop Now <ShoppingCart size={16} />
              </Link>
              <Link to="/products?category=Gift+Boxes"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-sm border-2 border-white/40 text-white hover:bg-white/10 transition-all">
                Gift Boxes <ChevronRight size={16} />
              </Link>
            </div>
            {/* Trust badges */}
            <div className="flex items-center gap-6 mt-10 flex-wrap">
              {[["4.9★", "10,000+ Happy Customers"], ["30+", "Days Shelf Life"], ["100%", "Pure Desi Ghee"]].map(([num, label]) => (
                <div key={label} className="flex items-center gap-2">
                  <span className="text-xl font-bold" style={{ color: "#F0C040" }}>{num}</span>
                  <span className="text-orange-200 text-xs">{label}</span>
                </div>
              ))}
            </div>
          </div>
          {/* Hero image */}
          <div className="hidden md:flex justify-center items-center fade-in">
            <div className="relative">
              <div className="w-80 h-80 rounded-full overflow-hidden border-4 border-yellow-400/30 shadow-2xl">
                <img src="https://images.unsplash.com/photo-1574484284002-952d92456975?w=640&h=640&fit=crop&auto=format"
                  alt="Premium Bihar Thekua" className="w-full h-full object-cover" />
              </div>
              {/* Floating badge */}
              <div className="absolute -bottom-4 -left-8 bg-white rounded-2xl px-4 py-3 shadow-xl">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">🪔</span>
                  <div>
                    <div className="text-xs text-gray-500 font-medium">Chhath Special</div>
                    <div style={{ fontFamily: "'Playfair Display', serif", color: "#C8421A" }} className="font-bold text-sm">Premium Thekua</div>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-8 bg-yellow-400 rounded-2xl px-3 py-2 shadow-xl">
                <div className="text-center">
                  <div className="text-red-800 font-bold text-lg leading-none">20%</div>
                  <div className="text-red-700 text-[10px] font-medium">OFF TODAY</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 60L1440 60L1440 30C1440 30 1080 0 720 0C360 0 0 30 0 30L0 60Z" fill="#FFF8F0" />
          </svg>
        </div>
      </section>

      {/* Features bar */}
      <section className="py-10 px-6 bg-white border-b border-orange-100">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: Truck, title: "Free Delivery", sub: "On orders above ₹499" },
            { icon: Shield, title: "100% Secure", sub: "Razorpay protected" },
            { icon: Clock, title: "Fresh Always", sub: "Made to order" },
            { icon: Award, title: "FSSAI Certified", sub: "Quality guaranteed" },
          ].map(({ icon: Icon, title, sub }) => (
            <div key={title} className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: "#FFF0E8" }}>
                <Icon size={20} style={{ color: "#C8421A" }} />
              </div>
              <div>
                <div className="font-semibold text-sm text-gray-800">{title}</div>
                <div className="text-xs text-gray-500">{sub}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 px-6" style={{ background: "#FFF8F0" }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-sm font-medium tracking-widest uppercase mb-2" style={{ color: "#C8421A" }}>Our Specialties</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl md:text-4xl font-bold text-gray-800">
              Explore Bihar's Finest Sweets
            </h2>
          </div>

          {/* Category pills */}
          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {categories.map(cat => (
              <button key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${activeCategory === cat ? "text-white shadow-md scale-105" : "text-gray-600 hover:bg-orange-50"}`}
                style={activeCategory === cat ? { background: "#C8421A" } : { background: "white", border: "1px solid #E5D5C5" }}>
                {cat}
              </button>
            ))}
          </div>

          {/* Products grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map(product => (
              <div key={product.id}
                className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group border border-orange-100">
                <div className="relative overflow-hidden">
                  <img src={product.image} alt={product.name}
                    className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-500" />
                  {product.badge && (
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold text-white shadow"
                      style={{ background: "#C8421A" }}>{product.badge}</span>
                  )}
                  <div className="absolute top-3 right-3 bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                    {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                  </div>
                </div>
                <div className="p-4">
                  <p className="text-xs text-gray-400 font-medium uppercase tracking-wide mb-1">{product.category} · {product.weight}</p>
                  <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="font-bold text-gray-800 text-base mb-1 leading-tight">{product.name}</h3>
                  <p className="text-xs text-gray-500 mb-3 line-clamp-2">{product.description}</p>
                  <div className="flex items-center gap-2 mb-3">
                    <StarRating rating={product.rating} />
                    <span className="text-xs text-gray-400">({product.reviews})</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-lg font-bold" style={{ color: "#C8421A" }}>₹{product.price}</span>
                      <span className="text-sm text-gray-400 line-through ml-1.5">₹{product.originalPrice}</span>
                    </div>
                    <button
                      onClick={() => handleAdd(product)}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-sm font-medium transition-all hover:scale-105 active:scale-95"
                      style={{ background: addedId === product.id ? "#16a34a" : "#C8421A", color: "white" }}>
                      {addedId === product.id ? "Added ✓" : <><Plus size={14} /> Add</>}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-10">
            <Link to="/products"
              style={{ border: "2px solid #C8421A", color: "#C8421A" }}
              className="inline-flex items-center gap-2 px-8 py-3 rounded-full font-semibold text-sm hover:bg-orange-50 transition-colors">
              View All Products <ChevronRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Festival banner */}
      <section className="py-16 px-6" style={{ background: "#8B1A1A" }}>
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-10 items-center">
          <div>
            <p className="text-yellow-400 text-sm font-medium uppercase tracking-widest mb-3">Chhath Puja Special</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl md:text-4xl font-bold text-white mb-4">
              Gift the Taste of Home This Festive Season
            </h2>
            <p className="text-orange-200 text-sm leading-relaxed mb-6">
              Send the authentic flavour of Bihar to your loved ones anywhere in India. Our curated gift boxes arrive beautifully packaged and ready to delight.
            </p>
            <Link to="/products?category=Gift+Boxes"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-sm transition-all hover:scale-105"
              style={{ background: "#D4A017", color: "#1C0A00" }}>
              Explore Gift Boxes <ChevronRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {products.filter(p => p.category === "Gift Boxes").slice(0, 2).map(p => (
              <div key={p.id} className="rounded-xl overflow-hidden shadow-lg">
                <img src={p.image} alt={p.name} className="w-full h-36 object-cover" />
                <div className="bg-white p-3">
                  <p className="text-xs font-semibold text-gray-700 truncate">{p.name}</p>
                  <p className="text-sm font-bold mt-0.5" style={{ color: "#C8421A" }}>₹{p.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-6" style={{ background: "#FFF8F0" }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-sm font-medium tracking-widest uppercase mb-2" style={{ color: "#C8421A" }}>Customer Love</p>
            <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800">
              10,000+ Happy Families
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "Priya Sinha", city: "Mumbai", text: "Ordered for Chhath — arrived fresh, perfectly packed. The taste took me back to my childhood in Patna. Will order again!", rating: 5 },
              { name: "Rahul Kumar", city: "Delhi", text: "Sent a gift box to my parents in Bihar and they were so surprised and happy. Quality is outstanding, truly authentic.", rating: 5 },
              { name: "Anita Devi", city: "Bengaluru", text: "The Dry Fruit Thekua is absolutely amazing. Using pure ghee makes all the difference. Fast delivery, lovely packaging!", rating: 5 },
            ].map(({ name, city, text, rating }) => (
              <div key={name} className="bg-white rounded-2xl p-6 shadow-sm border border-orange-100">
                <div className="flex items-center gap-0.5 mb-3">
                  {Array(rating).fill(0).map((_, i) => <Star key={i} size={14} className="fill-yellow-400 text-yellow-400" />)}
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4 italic">"{text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
                    style={{ background: "#C8421A" }}>{name[0]}</div>
                  <div>
                    <div className="font-semibold text-sm text-gray-800">{name}</div>
                    <div className="text-xs text-gray-400">{city}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <FAQ />
    </div>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(null);
  const faqs = [
    { q: "What is Thekua?", a: "Thekua is a traditional Bihari sweet made from whole wheat flour, jaggery, and desi ghee. It is the most important prasad of Chhath Puja and is cherished across Bihar." },
    { q: "Are your products free of preservatives?", a: "Yes! All our products are 100% free of preservatives, artificial colours, and flavours. We use only natural ingredients — pure desi ghee, natural jaggery, and whole wheat flour." },
    { q: "How long do your sweets last?", a: "Thekua lasts up to 30 days when stored in an airtight container at room temperature. Khaja lasts up to 45 days. Gift boxes include individual shelf-life information." },
    { q: "Do you ship pan-India?", a: "Yes! We ship to every corner of India. Orders above ₹499 qualify for free shipping. Express delivery options are also available." },
    { q: "Can I customise a gift box?", a: "Absolutely! Contact us at hello@biharithekua.com or WhatsApp +91 98765 43210 to create a custom gift hamper for any occasion." },
  ];
  return (
    <section id="faq" className="py-16 px-6 bg-white">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <p className="text-sm font-medium tracking-widest uppercase mb-2" style={{ color: "#C8421A" }}>FAQs</p>
          <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800">Frequently Asked Questions</h2>
        </div>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="border border-orange-100 rounded-xl overflow-hidden">
              <button onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex justify-between items-center px-5 py-4 text-left text-sm font-medium text-gray-800 hover:bg-orange-50 transition-colors">
                {faq.q}
                <ChevronRight size={16} className={`text-orange-500 transition-transform ${open === i ? "rotate-90" : ""}`} />
              </button>
              {open === i && (
                <div className="px-5 pb-4 text-sm text-gray-600 leading-relaxed border-t border-orange-100 bg-orange-50/30">
                  <div className="pt-3">{faq.a}</div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
