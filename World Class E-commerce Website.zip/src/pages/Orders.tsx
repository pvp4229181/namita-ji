import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Package, Clock, ChevronRight, AlertTriangle } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getUserOrders, updateOrder, Order } from "../services/db";

const statusColors: Record<string, { bg: string; text: string; label: string }> = {
  pending: { bg: "#FEF3C7", text: "#92400E", label: "Pending" },
  confirmed: { bg: "#DBEAFE", text: "#1E40AF", label: "Confirmed" },
  processing: { bg: "#EDE9FE", text: "#5B21B6", label: "Processing" },
  shipped: { bg: "#CFFAFE", text: "#164E63", label: "Shipped" },
  delivered: { bg: "#D1FAE5", text: "#065F46", label: "Delivered" },
  refund_requested: { bg: "#FEE2E2", text: "#991B1B", label: "Refund Requested" },
  refunded: { bg: "#F3F4F6", text: "#374151", label: "Refunded" },
  cancelled: { bg: "#FEE2E2", text: "#991B1B", label: "Cancelled" },
};

export default function Orders() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>(() => user ? getUserOrders(user.id) : []);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [refundReason, setRefundReason] = useState("");
  const [showRefundModal, setShowRefundModal] = useState(false);

  if (!user) { navigate("/login"); return null; }

  function handleRefundRequest() {
    if (!selectedOrder || !refundReason.trim()) return;
    const updated = updateOrder(selectedOrder.id, {
      status: "refund_requested",
      refundReason: refundReason.trim(),
      refundRequestedAt: new Date().toISOString(),
    });
    if (updated) {
      setOrders(prev => prev.map(o => o.id === updated.id ? updated : o));
    }
    setShowRefundModal(false);
    setRefundReason("");
    setSelectedOrder(null);
  }

  return (
    <div className="min-h-screen py-8 px-4" style={{ background: "#FFF8F0" }}>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Link to="/profile" className="text-sm text-gray-400 hover:text-gray-600">← Profile</Link>
          <ChevronRight size={14} className="text-gray-300" />
          <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-2xl font-bold text-gray-800">My Orders</h1>
        </div>

        {orders.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm border border-orange-100">
            <Package size={56} className="mx-auto mb-4 text-gray-200" />
            <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-gray-600 mb-2">No orders yet</h2>
            <p className="text-sm text-gray-400 mb-6">Discover our authentic Bihar sweets and place your first order!</p>
            <Link to="/products" style={{ background: "#C8421A" }} className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-white text-sm font-medium hover:opacity-90 transition-opacity">
              Start Shopping <ChevronRight size={16} />
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => {
              const statusInfo = statusColors[order.status] || { bg: "#F3F4F6", text: "#374151", label: order.status };
              return (
                <div key={order.id} className="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
                  {/* Header */}
                  <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 border-b border-orange-50">
                    <div>
                      <p className="text-xs text-gray-400 font-medium">ORDER ID</p>
                      <p className="font-bold text-gray-800">{order.id}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400 font-medium">DATE</p>
                      <p className="text-sm text-gray-700 flex items-center gap-1">
                        <Clock size={12} /> {new Date(order.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" })}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400 font-medium">TOTAL</p>
                      <p className="font-bold text-sm" style={{ color: "#C8421A" }}>₹{order.total}</p>
                    </div>
                    <span className="px-3 py-1.5 rounded-full text-xs font-bold"
                      style={{ background: statusInfo.bg, color: statusInfo.text }}>
                      {statusInfo.label}
                    </span>
                  </div>

                  {/* Items */}
                  <div className="px-5 py-4">
                    <div className="flex gap-3 mb-4">
                      {order.items.map((item, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <img src={item.image} alt={item.name} className="w-12 h-12 rounded-xl object-cover" />
                          <div>
                            <p className="text-xs font-medium text-gray-700 max-w-[120px] truncate">{item.name}</p>
                            <p className="text-xs text-gray-400">{item.weight} × {item.quantity}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Address */}
                    <p className="text-xs text-gray-400 mb-3">
                      📍 {order.address}, {order.city} — {order.pincode}
                    </p>

                    {/* Payment info */}
                    {order.paymentId && (
                      <p className="text-xs text-gray-400">💳 Payment ID: {order.paymentId}</p>
                    )}

                    {/* Refund reason */}
                    {order.refundReason && (
                      <div className="mt-3 p-3 rounded-lg bg-red-50 border border-red-100 text-xs text-red-600">
                        <strong>Refund Reason:</strong> {order.refundReason}
                        {order.refundRequestedAt && <span className="ml-2 text-red-400">({new Date(order.refundRequestedAt).toLocaleDateString("en-IN")})</span>}
                      </div>
                    )}

                    {/* Actions */}
                    {order.status === "delivered" && (
                      <button
                        onClick={() => { setSelectedOrder(order); setShowRefundModal(true); }}
                        className="mt-3 flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg text-red-600 border border-red-200 hover:bg-red-50 transition-colors">
                        <AlertTriangle size={13} /> Request Refund
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Refund modal */}
      {showRefundModal && selectedOrder && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl fade-in">
            <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-gray-800 mb-2">Request Refund</h3>
            <p className="text-sm text-gray-500 mb-4">Order: <strong>{selectedOrder.id}</strong></p>
            <div className="mb-4">
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Reason for Refund *</label>
              <textarea
                value={refundReason}
                onChange={e => setRefundReason(e.target.value)}
                rows={3}
                placeholder="Please describe the issue with your order..."
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none"
              />
            </div>
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3 mb-5 text-xs text-yellow-800">
              ⚠️ Refunds are processed within 5-7 business days after review.
            </div>
            <div className="flex gap-3">
              <button onClick={() => { setShowRefundModal(false); setRefundReason(""); setSelectedOrder(null); }}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">
                Cancel
              </button>
              <button onClick={handleRefundRequest} disabled={!refundReason.trim()}
                className="flex-1 py-3 rounded-xl text-white text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
                style={{ background: "#DC2626" }}>
                Submit Request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
