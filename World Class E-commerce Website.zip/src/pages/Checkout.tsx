import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { MapPin, Package, Shield, ChevronRight, Tag, XCircle } from "lucide-react";
import { useCart } from "../context/CartContext";
import { useAuth } from "../context/AuthContext";
import { createOrder } from "../services/db";

declare global {
  interface Window {
    Razorpay: new (options: RazorpayOptions) => RazorpayInstance;
  }
}

interface RazorpayOptions {
  key: string;
  amount: number;
  currency: string;
  name: string;
  description: string;
  image?: string;
  order_id?: string;
  handler: (response: RazorpayResponse) => void;
  prefill: { name: string; email: string; contact: string };
  notes?: Record<string, string>;
  theme: { color: string };
  modal?: { ondismiss?: () => void };
}

interface RazorpayResponse {
  razorpay_payment_id: string;
  razorpay_order_id?: string;
  razorpay_signature?: string;
}

interface RazorpayInstance {
  open: () => void;
}

const RAZORPAY_KEY = "rzp_test_YourKeyHere"; // Replace with your Razorpay Test Key

function loadRazorpay(): Promise<boolean> {
  return new Promise(resolve => {
    if (window.Razorpay) { resolve(true); return; }
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function Checkout() {
  const { items, subtotal, couponDiscount, deliveryCharge, total, appliedCoupon, clearCart, removeCoupon } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [address, setAddress] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    address: user?.address || "",
    city: user?.city || "",
    pincode: user?.pincode || "",
  });
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState<"address" | "review">("address");

  useEffect(() => {
    if (!user) { navigate("/login?redirect=/checkout"); return; }
    if (items.length === 0) { navigate("/"); }
  }, [user, items]);

  async function handlePayment() {
    if (!address.address || !address.city || !address.pincode) {
      setError("Please fill in all address fields.");
      setStep("address");
      return;
    }
    setPaymentLoading(true);
    setError("");

    const loaded = await loadRazorpay();
    if (!loaded) {
      setError("Failed to load payment gateway. Please check your connection.");
      setPaymentLoading(false);
      return;
    }

    // In production: call your backend to create Razorpay order
    // POST /api/create-order { amount: total * 100 }
    // Use the returned order_id in options.order_id

    const options: RazorpayOptions = {
      key: RAZORPAY_KEY,
      amount: total * 100, // in paise
      currency: "INR",
      name: "Bihari Thekua Online",
      description: `Order of ${items.length} item(s)`,
      handler: function(response: RazorpayResponse) {
        handlePaymentSuccess(response);
      },
      prefill: {
        name: address.name,
        email: user!.email,
        contact: address.phone,
      },
      notes: {
        address: `${address.address}, ${address.city} - ${address.pincode}`,
        userId: user!.id,
      },
      theme: { color: "#C8421A" },
      modal: {
        ondismiss: () => {
          setPaymentLoading(false);
        },
      },
    };

    try {
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch {
      setError("Failed to open payment gateway.");
      setPaymentLoading(false);
    }
  }

  function handlePaymentSuccess(response: RazorpayResponse) {
    // Create order in database
    const order = createOrder({
      userId: user!.id,
      userName: address.name,
      userEmail: user!.email,
      userPhone: address.phone,
      items: items.map(i => ({
        productId: i.id,
        name: i.name,
        price: i.price,
        quantity: i.quantity,
        weight: i.weight,
        image: i.image,
      })),
      subtotal,
      discount: 0,
      couponCode: appliedCoupon || undefined,
      deliveryCharge,
      total,
      status: "confirmed",
      paymentId: response.razorpay_payment_id,
      razorpayOrderId: response.razorpay_order_id,
      paymentStatus: "paid",
      address: address.address,
      city: address.city,
      pincode: address.pincode,
    });

    clearCart();
    navigate(`/order-success/${order.id}`);
  }

  if (!user || items.length === 0) return null;

  return (
    <div className="min-h-screen py-8 px-4" style={{ background: "#FFF8F0" }}>
      <div className="max-w-5xl mx-auto">
        <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl font-bold text-gray-800 mb-8">Checkout</h1>

        {/* Steps */}
        <div className="flex items-center gap-3 mb-8">
          {[{ id: "address", label: "Address" }, { id: "review", label: "Review & Pay" }].map((s, i) => (
            <div key={s.id} className="flex items-center gap-3">
              <button onClick={() => s.id === "review" ? setStep("review") : setStep("address")}
                className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${step === s.id ? "text-white" : "bg-gray-200 text-gray-500"}`}
                  style={step === s.id ? { background: "#C8421A" } : {}}>
                  {i + 1}
                </div>
                <span className={`text-sm font-medium ${step === s.id ? "" : "text-gray-400"}`} style={step === s.id ? { color: "#C8421A" } : {}}>{s.label}</span>
              </button>
              {i < 1 && <ChevronRight size={14} className="text-gray-300" />}
            </div>
          ))}
        </div>

        {error && (
          <div className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>
        )}

        <div className="grid lg:grid-cols-[1fr_380px] gap-8">
          {/* Left */}
          <div className="space-y-5">
            {step === "address" ? (
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-orange-100">
                <h2 className="font-semibold text-gray-800 mb-5 flex items-center gap-2">
                  <MapPin size={18} style={{ color: "#C8421A" }} /> Delivery Address
                </h2>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1.5">Full Name *</label>
                      <input value={address.name} onChange={e => setAddress({ ...address, name: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1.5">Phone Number *</label>
                      <input value={address.phone} onChange={e => setAddress({ ...address, phone: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-500 mb-1.5">Street Address *</label>
                    <textarea value={address.address} onChange={e => setAddress({ ...address, address: e.target.value })}
                      rows={2} placeholder="House no, Street, Area, Landmark"
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1.5">City *</label>
                      <input value={address.city} onChange={e => setAddress({ ...address, city: e.target.value })}
                        placeholder="Patna" className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1.5">PIN Code *</label>
                      <input value={address.pincode} onChange={e => setAddress({ ...address, pincode: e.target.value })}
                        placeholder="800001" className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
                    </div>
                  </div>
                  <button onClick={() => { if (!address.address || !address.city || !address.pincode) { setError("Please fill all required fields."); return; } setError(""); setStep("review"); }}
                    style={{ background: "#C8421A" }}
                    className="w-full py-3.5 rounded-xl text-white font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity mt-2">
                    Continue to Review <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Address review */}
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-semibold text-sm text-gray-800 flex items-center gap-2">
                      <MapPin size={16} style={{ color: "#C8421A" }} /> Delivery to
                    </h3>
                    <button onClick={() => setStep("address")} style={{ color: "#C8421A" }} className="text-xs font-medium hover:underline">Change</button>
                  </div>
                  <p className="text-sm text-gray-700 font-medium">{address.name} · {address.phone}</p>
                  <p className="text-xs text-gray-500 mt-1">{address.address}, {address.city} — {address.pincode}</p>
                </div>

                {/* Order items */}
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100">
                  <h3 className="font-semibold text-sm text-gray-800 flex items-center gap-2 mb-4">
                    <Package size={16} style={{ color: "#C8421A" }} /> Order Items ({items.length})
                  </h3>
                  <div className="space-y-3">
                    {items.map(item => (
                      <div key={item.id} className="flex gap-3 items-center">
                        <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-800">{item.name}</p>
                          <p className="text-xs text-gray-400">{item.weight} × {item.quantity}</p>
                        </div>
                        <span className="text-sm font-bold" style={{ color: "#C8421A" }}>₹{item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Right — Order summary */}
          <div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-orange-100 sticky top-24">
              <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="font-bold text-gray-800 text-lg mb-5">Order Summary</h3>

              {/* Applied coupon */}
              {appliedCoupon && (
                <div className="flex items-center justify-between mb-4 bg-green-50 border border-green-200 rounded-xl px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <Tag size={14} className="text-green-600" />
                    <div>
                      <span className="text-xs font-semibold text-green-700">{appliedCoupon} applied</span>
                      <p className="text-[10px] text-green-600">You save ₹{couponDiscount}!</p>
                    </div>
                  </div>
                  <button onClick={removeCoupon} className="text-red-400 hover:text-red-600"><XCircle size={15} /></button>
                </div>
              )}

              <div className="space-y-2.5 text-sm border-b border-orange-100 pb-4 mb-4">
                <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>₹{subtotal}</span></div>
                {couponDiscount > 0 && <div className="flex justify-between text-green-600"><span>Coupon ({appliedCoupon})</span><span>-₹{couponDiscount}</span></div>}
                <div className="flex justify-between text-gray-600">
                  <span>Delivery</span>
                  <span>{deliveryCharge === 0 ? <span className="text-green-600 font-medium">FREE</span> : `₹${deliveryCharge}`}</span>
                </div>
              </div>

              <div className="flex justify-between font-bold text-base mb-6" style={{ color: "#C8421A" }}>
                <span>Total</span><span>₹{total}</span>
              </div>

              {step === "review" && (
                <button
                  onClick={handlePayment}
                  disabled={paymentLoading}
                  style={{ background: "#C8421A" }}
                  className="w-full py-4 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-70 shadow-lg shadow-orange-200">
                  {paymentLoading ? "Opening Payment..." : `Pay ₹${total} via Razorpay`}
                </button>
              )}

              <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-400">
                <Shield size={13} /> 100% Secure · Encrypted Payment
              </div>
              <p className="text-center text-[10px] text-gray-300 mt-1">Powered by Razorpay</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
