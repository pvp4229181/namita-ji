export interface Product {
  id: string;
  name: string;
  category: string;
  description: string;
  longDescription: string;
  price: number;
  originalPrice: number;
  weight: string;
  image: string;
  badge?: string;
  inStock: boolean;
  rating: number;
  reviews: number;
  ingredients: string;
  shelfLife: string;
}

export const categories = ["All", "Thekua", "Laddoo", "Khaja", "Tilkut", "Gift Boxes"];

export const products: Product[] = [
  {
    id: "p1",
    name: "Classic Khasta Thekua",
    category: "Thekua",
    description: "Traditional handcrafted Thekua made with desi ghee and jaggery",
    longDescription: "Our Classic Khasta Thekua is lovingly crafted using age-old Bihar recipes passed down through generations. Made with pure desi ghee, whole wheat flour, and natural jaggery — no preservatives, no artificial colours. FSSAI certified.",
    price: 249,
    originalPrice: 320,
    weight: "250g",
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&h=500&fit=crop&auto=format",
    badge: "Bestseller",
    inStock: true,
    rating: 4.8,
    reviews: 324,
    ingredients: "Whole wheat flour, Jaggery, Desi ghee, Fennel seeds, Cardamom",
    shelfLife: "30 days"
  },
  {
    id: "p2",
    name: "Classic Khasta Thekua",
    category: "Thekua",
    description: "Family pack — perfect for festivals and gifting",
    longDescription: "Same beloved recipe in a generous 500g pack. Ideal for Chhath Puja, Diwali, and family gatherings.",
    price: 449,
    originalPrice: 580,
    weight: "500g",
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=600&h=500&fit=crop&auto=format",
    badge: "Popular",
    inStock: true,
    rating: 4.9,
    reviews: 218,
    ingredients: "Whole wheat flour, Jaggery, Desi ghee, Fennel seeds, Cardamom",
    shelfLife: "30 days"
  },
  {
    id: "p3",
    name: "Premium Dry Fruit Thekua",
    category: "Thekua",
    description: "Enriched with cashews, almonds and saffron — the royal variant",
    longDescription: "A premium take on the classic, our Dry Fruit Thekua is loaded with handpicked cashews, almonds, pistachios and a touch of Kashmiri saffron. Perfect as a luxury gift.",
    price: 349,
    originalPrice: 450,
    weight: "250g",
    image: "https://images.unsplash.com/photo-1574484284002-952d92456975?w=600&h=500&fit=crop&auto=format",
    badge: "Premium",
    inStock: true,
    rating: 4.7,
    reviews: 156,
    ingredients: "Whole wheat flour, Jaggery, Desi ghee, Cashews, Almonds, Pistachios, Saffron, Cardamom",
    shelfLife: "25 days"
  },
  {
    id: "p4",
    name: "Sugar-Free Thekua",
    category: "Thekua",
    description: "Diabetic-friendly, sweetened naturally with dates and stevia",
    longDescription: "Enjoy the authentic taste of Thekua without worry. Our Sugar-Free variant uses natural dates and stevia, making it perfect for health-conscious and diabetic customers.",
    price: 299,
    originalPrice: 380,
    weight: "250g",
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&h=500&fit=crop&auto=format",
    badge: "Diabetic Friendly",
    inStock: true,
    rating: 4.5,
    reviews: 89,
    ingredients: "Whole wheat flour, Dates, Stevia, Desi ghee, Fennel seeds",
    shelfLife: "20 days"
  },
  {
    id: "p5",
    name: "Besan Laddoo",
    category: "Laddoo",
    description: "Roasted chickpea flour laddoos with pure ghee and cardamom",
    longDescription: "Hand-rolled Besan Laddoos made with slow-roasted chickpea flour in generous desi ghee. Melt-in-mouth texture, aromatic with green cardamom.",
    price: 299,
    originalPrice: 380,
    weight: "500g",
    image: "https://images.unsplash.com/photo-1599599810694-b5b37304c041?w=600&h=500&fit=crop&auto=format",
    inStock: true,
    rating: 4.6,
    reviews: 142,
    ingredients: "Chickpea flour, Desi ghee, Powdered sugar, Cardamom, Cashews",
    shelfLife: "30 days"
  },
  {
    id: "p6",
    name: "Motichoor Laddoo",
    category: "Laddoo",
    description: "Delicate saffron-tinted pearls bound in sugar syrup",
    longDescription: "Tiny, perfectly-formed boondi tossed in fragrant sugar syrup, rolled into the iconic Motichoor Laddoo. A festival staple across Bihar and UP.",
    price: 349,
    originalPrice: 420,
    weight: "500g",
    image: "https://images.unsplash.com/photo-1630409351241-e90e7f3e84f4?w=600&h=500&fit=crop&auto=format",
    badge: "Festival Special",
    inStock: true,
    rating: 4.8,
    reviews: 201,
    ingredients: "Chickpea flour, Sugar, Saffron, Rose water, Cardamom, Pistachios",
    shelfLife: "15 days"
  },
  {
    id: "p7",
    name: "Bihari Khaja",
    category: "Khaja",
    description: "Flaky layered sweet — the pride of Silao, Bihar",
    longDescription: "Originating from Silao near Rajgir, our Khaja is crafted with the same age-old technique — multiple thin layers of dough, fried to golden perfection and soaked in sugar syrup.",
    price: 269,
    originalPrice: 340,
    weight: "400g",
    image: "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=600&h=500&fit=crop&auto=format",
    badge: "Heritage Recipe",
    inStock: true,
    rating: 4.7,
    reviews: 178,
    ingredients: "Refined flour, Sugar, Ghee, Milk",
    shelfLife: "45 days"
  },
  {
    id: "p8",
    name: "Sesame Tilkut",
    category: "Tilkut",
    description: "Gaya's famous white sesame brittle — a Makar Sankranti tradition",
    longDescription: "Made from white sesame seeds and sugar, our Tilkut is hand-pounded the traditional Gaya way. Crunchy, nutty, and irresistibly addictive.",
    price: 229,
    originalPrice: 290,
    weight: "300g",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=500&fit=crop&auto=format",
    inStock: true,
    rating: 4.6,
    reviews: 93,
    ingredients: "White sesame seeds, Sugar, Cardamom",
    shelfLife: "60 days"
  },
  {
    id: "p9",
    name: "Chhath Puja Gift Box",
    category: "Gift Boxes",
    description: "Curated assortment of 5 traditional Bihar sweets for the festival",
    longDescription: "A beautifully packaged gift box containing Thekua, Khaja, Laddoo, Tilkut, and Dry Fruit Thekua — everything you need to celebrate Chhath Puja or send blessings to loved ones.",
    price: 999,
    originalPrice: 1350,
    weight: "1.2kg",
    image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600&h=500&fit=crop&auto=format",
    badge: "Limited Edition",
    inStock: true,
    rating: 4.9,
    reviews: 312,
    ingredients: "Assorted — see individual products",
    shelfLife: "20 days"
  },
  {
    id: "p10",
    name: "Corporate Gift Hamper",
    category: "Gift Boxes",
    description: "Premium hamper with 8 varieties — ideal for Diwali corporate gifting",
    longDescription: "Impress your clients and colleagues with our curated Corporate Hamper featuring 8 handpicked Bihar specialties in a premium wooden box. Includes personalised message card.",
    price: 1799,
    originalPrice: 2400,
    weight: "2.5kg",
    image: "https://images.unsplash.com/photo-1607344645866-009c320b63e0?w=600&h=500&fit=crop&auto=format",
    badge: "Corporate",
    inStock: true,
    rating: 4.8,
    reviews: 87,
    ingredients: "Assorted — see individual products",
    shelfLife: "20 days"
  },
  {
    id: "p11",
    name: "Boondi Raita Mix (Sweet)",
    category: "Thekua",
    description: "Crispy boondi with jaggery — a classic Bihar snack",
    longDescription: "Freshly made crispy boondi tossed with powdered jaggery and fennel — a beloved Bihar evening snack that pairs perfectly with chai.",
    price: 179,
    originalPrice: 220,
    weight: "200g",
    image: "https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=600&h=500&fit=crop&auto=format",
    inStock: true,
    rating: 4.4,
    reviews: 56,
    ingredients: "Chickpea flour, Jaggery, Fennel, Desi ghee",
    shelfLife: "20 days"
  },
  {
    id: "p12",
    name: "Premium Dry Fruit Thekua",
    category: "Thekua",
    description: "The ultimate large pack — for weddings, bulk orders",
    longDescription: "Our bestselling Premium Dry Fruit Thekua in a 900g bulk pack. Perfect for weddings, large family celebrations, and bulk gifting.",
    price: 849,
    originalPrice: 1100,
    weight: "900g",
    image: "https://images.unsplash.com/photo-1516684732162-798a0062be99?w=600&h=500&fit=crop&auto=format",
    badge: "Bulk Value",
    inStock: true,
    rating: 4.8,
    reviews: 143,
    ingredients: "Whole wheat flour, Jaggery, Desi ghee, Cashews, Almonds, Pistachios, Saffron",
    shelfLife: "25 days"
  }
];

export const coupons: Record<string, { discount: number; type: "percent" | "flat"; minOrder: number }> = {
  "WELCOME10": { discount: 10, type: "percent", minOrder: 0 },
  "CHHATH20": { discount: 20, type: "percent", minOrder: 500 },
  "FLAT100": { discount: 100, type: "flat", minOrder: 300 },
  "BIHAR50": { discount: 50, type: "flat", minOrder: 200 },
  "FIRSTORDER": { discount: 15, type: "percent", minOrder: 0 },
};
