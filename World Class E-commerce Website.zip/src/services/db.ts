// Local storage-based database service
// In production: replace API calls with your Node.js/Express + MongoDB backend

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  password: string; // hashed in production
  address: string;
  city: string;
  pincode: string;
  createdAt: string;
  role: "user" | "admin";
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  weight: string;
  image: string;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  deliveryCharge: number;
  total: number;
  status: "pending" | "confirmed" | "processing" | "shipped" | "delivered" | "refund_requested" | "refunded" | "cancelled";
  paymentId?: string;
  razorpayOrderId?: string;
  paymentStatus: "pending" | "paid" | "failed" | "refunded";
  address: string;
  city: string;
  pincode: string;
  createdAt: string;
  updatedAt: string;
  refundReason?: string;
  refundRequestedAt?: string;
}

const USERS_KEY = "bihari_users";
const ORDERS_KEY = "bihari_orders";
const SESSION_KEY = "bihari_session";

// ─── USER OPERATIONS ───────────────────────────────────────────────────────────

export function getAllUsers(): User[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch { return []; }
}

export function saveUser(user: User): void {
  const users = getAllUsers();
  const idx = users.findIndex(u => u.id === user.id);
  if (idx >= 0) users[idx] = user;
  else users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function findUserByEmail(email: string): User | null {
  return getAllUsers().find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
}

export function findUserById(id: string): User | null {
  return getAllUsers().find(u => u.id === id) || null;
}

export function createUser(data: Omit<User, "id" | "createdAt" | "role">): User {
  const user: User = {
    ...data,
    id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    createdAt: new Date().toISOString(),
    role: "user",
  };
  saveUser(user);
  return user;
}

export function updateUser(id: string, updates: Partial<User>): User | null {
  const users = getAllUsers();
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return null;
  users[idx] = { ...users[idx], ...updates };
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  return users[idx];
}

// ─── SESSION OPERATIONS ────────────────────────────────────────────────────────

export function getSession(): User | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const { userId } = JSON.parse(raw);
    return findUserById(userId);
  } catch { return null; }
}

export function setSession(user: User): void {
  localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: user.id }));
}

export function clearSession(): void {
  localStorage.removeItem(SESSION_KEY);
}

// ─── ORDER OPERATIONS ──────────────────────────────────────────────────────────

export function getAllOrders(): Order[] {
  try {
    return JSON.parse(localStorage.getItem(ORDERS_KEY) || "[]");
  } catch { return []; }
}

export function saveOrder(order: Order): void {
  const orders = getAllOrders();
  const idx = orders.findIndex(o => o.id === order.id);
  if (idx >= 0) orders[idx] = order;
  else orders.unshift(order);
  localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
}

export function createOrder(data: Omit<Order, "id" | "createdAt" | "updatedAt">): Order {
  const order: Order = {
    ...data,
    id: `ORD${Date.now()}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  saveOrder(order);
  return order;
}

export function updateOrder(id: string, updates: Partial<Order>): Order | null {
  const orders = getAllOrders();
  const idx = orders.findIndex(o => o.id === id);
  if (idx < 0) return null;
  orders[idx] = { ...orders[idx], ...updates, updatedAt: new Date().toISOString() };
  localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
  return orders[idx];
}

export function getUserOrders(userId: string): Order[] {
  return getAllOrders().filter(o => o.userId === userId);
}

export function getOrderById(id: string): Order | null {
  return getAllOrders().find(o => o.id === id) || null;
}

// ─── SEED ADMIN ────────────────────────────────────────────────────────────────

export function seedAdmin(): void {
  const existing = findUserByEmail("admin@biharithekua.com");
  if (!existing) {
    const admin: User = {
      id: "admin_001",
      name: "Admin",
      email: "admin@biharithekua.com",
      phone: "9999999999",
      password: "Admin@123",
      address: "Bihar Bhawan",
      city: "Patna",
      pincode: "800001",
      createdAt: new Date().toISOString(),
      role: "admin",
    };
    saveUser(admin);
  }
}

// Simple hash (use bcrypt in production backend)
export function hashPassword(password: string): string {
  return btoa(password + "bihari_salt_2024");
}

export function verifyPassword(plain: string, hashed: string): boolean {
  return hashPassword(plain) === hashed;
}
